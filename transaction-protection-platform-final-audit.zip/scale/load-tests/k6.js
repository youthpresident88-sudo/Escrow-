import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  scenarios: {
    api_read: { executor: 'constant-arrival-rate', rate: 100, timeUnit: '1s', duration: '5m', preAllocatedVUs: 100, maxVUs: 1000 },
  },
  thresholds: {
    http_req_failed: ['rate<0.01'],
    http_req_duration: ['p(95)<500', 'p(99)<1000'],
  },
};

const BASE = __ENV.BASE_URL || 'http://localhost:4000';
export default function () {
  const r = http.get(`${BASE}/health`);
  check(r, { 'health 200': x => x.status === 200 });
  sleep(0.1);
}
