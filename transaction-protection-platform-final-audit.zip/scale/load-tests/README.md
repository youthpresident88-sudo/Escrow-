# Load testing

Run against a staging environment only. Do not run load tests against production payment webhooks or live financial providers.

Example:

```bash
k6 run -e BASE_URL=https://staging-api.example.com load-tests/k6.js
```

The baseline tests sustained API reads. Before launch, add authenticated scenarios for:

- transaction creation
- transaction list cursor pagination
- evidence metadata reads
- evidence upload initialization
- notification enqueue
- dispute case list/review
- webhook ingestion

Also run a separate storage test with representative 50MB/250MB/1GB videos using TUS. Measure API p95/p99, DB CPU/connections/locks, queue age, storage throughput, worker lag and provider error rates.

Do not claim a scale target is met until a staging test records the measured result.
