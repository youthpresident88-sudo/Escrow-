-- Production payment infrastructure hardening.
create type public.payment_operation as enum ('authorization','confirmation','refund','payout','reconciliation');
create type public.payment_event_kind as enum ('initialized','authorization_pending','authorized','successful','failed','cancelled','expired','reversed','refund_requested','refund_pending','refund_processing','refund_processed','refund_failed','payout_requested','payout_processing','payout_completed','payout_failed','reconciled');

alter table public.payments add column if not exists provider_customer_reference text;
alter table public.payments add column if not exists channel text;
alter table public.payments add column if not exists authorized_at timestamptz;
alter table public.payments add column if not exists settled_at timestamptz;
alter table public.payments add column if not exists failure_code text;
alter table public.payments add column if not exists failure_reason text;
alter table public.payments add column if not exists expires_at timestamptz;
alter table public.payments add column if not exists idempotency_key text;
alter table public.payments add column if not exists provider_status text;
alter table public.payments add column if not exists amount_refunded_minor bigint not null default 0;
alter table public.payments add column if not exists amount_paid_minor bigint not null default 0;
create unique index if not exists payments_idempotency_unique on public.payments(idempotency_key) where idempotency_key is not null;
create index if not exists payments_status_updated_idx on public.payments(status,updated_at);
create index if not exists payments_provider_reference_idx on public.payments(provider,provider_reference);

create table if not exists public.payment_events(
 id uuid primary key default gen_random_uuid(),
 payment_id uuid references public.payments(id) on delete restrict,
 transaction_id uuid not null references public.transactions(id) on delete restrict,
 provider text not null,
 provider_event_id text,
 kind public.payment_event_kind not null,
 provider_status text,
 amount_minor bigint,
 currency char(3),
 payload jsonb not null default '{}',
 idempotency_key text not null unique,
 occurred_at timestamptz not null default now(),
 created_at timestamptz not null default now()
);
create unique index if not exists payment_events_provider_event_unique on public.payment_events(provider,provider_event_id) where provider_event_id is not null;
create index if not exists payment_events_tx_idx on public.payment_events(transaction_id,created_at desc);

create table if not exists public.payment_operations(
 id uuid primary key default gen_random_uuid(),
 payment_id uuid references public.payments(id) on delete restrict,
 transaction_id uuid not null references public.transactions(id) on delete restrict,
 operation public.payment_operation not null,
 provider text not null,
 provider_reference text,
 amount_minor bigint,
 currency char(3),
 status text not null,
 idempotency_key text not null unique,
 request jsonb not null default '{}',
 response jsonb,
 error text,
 created_at timestamptz not null default now(),
 completed_at timestamptz
);
create index if not exists payment_operations_tx_idx on public.payment_operations(transaction_id,created_at desc);

create table if not exists public.payment_reconciliation_runs(
 id uuid primary key default gen_random_uuid(),
 provider text not null,
 started_at timestamptz not null default now(),
 completed_at timestamptz,
 scanned_count integer not null default 0,
 corrected_count integer not null default 0,
 failed_count integer not null default 0,
 status text not null default 'running' check(status in ('running','completed','failed')),
 error text
);

create table if not exists public.payouts(
 id uuid primary key default gen_random_uuid(),
 transaction_id uuid not null references public.transactions(id) on delete restrict,
 payment_id uuid references public.payments(id) on delete restrict,
 provider text not null,
 provider_reference text unique,
 recipient_reference text,
 amount_minor bigint not null check(amount_minor>0),
 currency char(3) not null,
 status text not null check(status in ('initiated','pending','processing','successful','failed','reversed')),
 metadata jsonb not null default '{}',
 idempotency_key text not null unique,
 failure_reason text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create index if not exists payouts_tx_idx on public.payouts(transaction_id,created_at desc);

alter table public.payment_events enable row level security;
alter table public.payment_operations enable row level security;
alter table public.payment_reconciliation_runs enable row level security;
alter table public.payouts enable row level security;
create policy payment_events_participant on public.payment_events for select using(exists(select 1 from public.transactions t where t.id=transaction_id and (t.buyer_id=auth.uid() or t.seller_id=auth.uid() or public.is_staff(auth.uid()))));
create policy payment_operations_staff on public.payment_operations for select using(public.is_staff(auth.uid()));
create policy payment_reconciliation_staff on public.payment_reconciliation_runs for select using(public.is_staff(auth.uid()));
create policy payouts_participant on public.payouts for select using(exists(select 1 from public.transactions t where t.id=transaction_id and (t.buyer_id=auth.uid() or t.seller_id=auth.uid() or public.is_staff(auth.uid()))));
