-- Production identity verification, trust and risk infrastructure

do $$ begin create type public.identity_verification_kind as enum ('identity','document','selfie_liveness','business'); exception when duplicate_object then null; end $$;
do $$ begin create type public.identity_review_status as enum ('not_required','pending','approved','rejected'); exception when duplicate_object then null; end $$;
do $$ begin create type public.risk_severity as enum ('low','medium','high','critical'); exception when duplicate_object then null; end $$;
do $$ begin create type public.risk_case_status as enum ('open','under_review','restricted','resolved','dismissed'); exception when duplicate_object then null; end $$;
do $$ begin create type public.risk_action as enum ('none','step_up_verification','limit_payments','limit_transactions','hold_payout','require_manual_review','temporary_restriction'); exception when duplicate_object then null; end $$;

create table if not exists public.identity_verification_attempts(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 kind public.identity_verification_kind not null,
 provider text not null,
 provider_reference text,
 status public.identity_verification_status not null default 'pending',
 review_status public.identity_review_status not null default 'not_required',
 rejection_reason text,
 retry_count integer not null default 0,
 document_type text,
 country_code char(2),
 provider_status text,
 metadata jsonb not null default '{}',
 requested_at timestamptz not null default now(),
 completed_at timestamptz,
 expires_at timestamptz,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 unique(provider,provider_reference)
);
create index if not exists identity_attempt_user_idx on public.identity_verification_attempts(user_id,created_at desc);

create table if not exists public.identity_review_events(
 id uuid primary key default gen_random_uuid(),
 verification_id uuid not null references public.identity_verification_attempts(id) on delete cascade,
 actor_id uuid references public.profiles(id) on delete set null,
 event_type text not null,
 reason text,
 metadata jsonb not null default '{}',
 created_at timestamptz not null default now()
);

create table if not exists public.trust_profiles(
 user_id uuid primary key references public.profiles(id) on delete cascade,
 completed_protected_transactions integer not null default 0,
 successful_transactions integer not null default 0,
 dispute_count integer not null default 0,
 seller_fault_dispute_count integer not null default 0,
 refund_count integer not null default 0,
 legitimate_return_count integer not null default 0,
 average_dispatch_seconds numeric(18,3),
 account_age_days integer not null default 0,
 identity_verification_status public.identity_verification_status not null default 'pending',
 calculated_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table if not exists public.risk_events(
 id uuid primary key default gen_random_uuid(),
 user_id uuid references public.profiles(id) on delete set null,
 transaction_id uuid references public.transactions(id) on delete set null,
 signal_type text not null,
 severity public.risk_severity not null,
 score_delta integer not null default 0,
 confidence numeric(5,4),
 evidence jsonb not null default '{}',
 source text not null,
 occurred_at timestamptz not null default now(),
 created_at timestamptz not null default now()
);
create index if not exists risk_events_user_idx on public.risk_events(user_id,created_at desc);
create index if not exists risk_events_transaction_idx on public.risk_events(transaction_id,created_at desc);

create table if not exists public.risk_cases(
 id uuid primary key default gen_random_uuid(),
 user_id uuid references public.profiles(id) on delete set null,
 transaction_id uuid references public.transactions(id) on delete set null,
 status public.risk_case_status not null default 'open',
 severity public.risk_severity not null default 'medium',
 risk_score integer not null default 0,
 action public.risk_action not null default 'none',
 assigned_to uuid references public.profiles(id) on delete set null,
 reason text,
 resolution text,
 opened_at timestamptz not null default now(),
 resolved_at timestamptz,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create index if not exists risk_cases_user_idx on public.risk_cases(user_id,status,created_at desc);
create index if not exists risk_cases_assignee_idx on public.risk_cases(assigned_to,status,created_at desc);

create table if not exists public.risk_case_events(
 id uuid primary key default gen_random_uuid(),
 case_id uuid not null references public.risk_cases(id) on delete cascade,
 actor_id uuid references public.profiles(id) on delete set null,
 event_type text not null,
 from_status public.risk_case_status,
 to_status public.risk_case_status,
 action public.risk_action,
 reason text,
 metadata jsonb not null default '{}',
 created_at timestamptz not null default now()
);

create table if not exists public.account_restrictions(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 restriction_type text not null,
 active boolean not null default true,
 reason text not null,
 case_id uuid references public.risk_cases(id) on delete set null,
 created_by uuid references public.profiles(id) on delete set null,
 starts_at timestamptz not null default now(),
 ends_at timestamptz,
 lifted_at timestamptz,
 lifted_by uuid references public.profiles(id) on delete set null,
 created_at timestamptz not null default now()
);
create index if not exists account_restrictions_active_idx on public.account_restrictions(user_id,active,ends_at);

alter table public.identity_verification_attempts enable row level security;
alter table public.identity_review_events enable row level security;
alter table public.trust_profiles enable row level security;
alter table public.risk_events enable row level security;
alter table public.risk_cases enable row level security;
alter table public.risk_case_events enable row level security;
alter table public.account_restrictions enable row level security;

create policy identity_attempt_self on public.identity_verification_attempts for select using(user_id=auth.uid() or public.is_staff(auth.uid()));
create policy identity_review_staff on public.identity_review_events for select using(public.is_staff(auth.uid()));
create policy trust_profile_self on public.trust_profiles for select using(user_id=auth.uid() or public.is_staff(auth.uid()));
create policy risk_events_staff on public.risk_events for select using(public.is_staff(auth.uid()));
create policy risk_cases_staff on public.risk_cases for all using(public.is_staff(auth.uid())) with check(public.is_staff(auth.uid()));
create policy risk_case_events_staff on public.risk_case_events for select using(public.is_staff(auth.uid()));
create policy restrictions_self_read on public.account_restrictions for select using(user_id=auth.uid() or public.is_staff(auth.uid()));

create or replace function public.refresh_trust_profile(p_user_id uuid) returns public.trust_profiles language plpgsql security definer set search_path=public as $$
declare r public.trust_profiles;
begin
 insert into public.trust_profiles(user_id,account_age_days,identity_verification_status)
 select p_user_id,greatest(0,extract(day from now()-p.created_at)::int),coalesce((select status from identity_verifications where user_id=p_user_id order by created_at desc limit 1),'pending')
 from profiles p where p.id=p_user_id on conflict(user_id) do nothing;
 update trust_profiles tp set
 completed_protected_transactions=(select count(*) from transactions t where (t.buyer_id=p_user_id or t.seller_id=p_user_id) and t.status in ('accepted','paid_out','resolved','refunded')),
 successful_transactions=(select count(*) from transactions t where (t.buyer_id=p_user_id or t.seller_id=p_user_id) and t.status in ('accepted','paid_out')),
 dispute_count=(select count(*) from disputes d where d.opened_by=p_user_id or exists(select 1 from transaction_participants tp2 where tp2.transaction_id=d.transaction_id and tp2.user_id=p_user_id)),
 seller_fault_dispute_count=(select count(*) from disputes d where d.opened_by=p_user_id and d.reason in ('wrong_product','wrong_specification','damaged','missing_item','wrong_quantity','significantly_different','counterfeit_suspected')),
 refund_count=(select count(*) from refund_requests rr join transactions t on t.id=rr.transaction_id where t.buyer_id=p_user_id and rr.status='processed'),
 legitimate_return_count=(select count(*) from returns r join transactions t on t.id=r.transaction_id where t.buyer_id=p_user_id),
 average_dispatch_seconds=(select avg(extract(epoch from (te2.created_at-te1.created_at))) from transaction_events te1 join transaction_events te2 on te2.transaction_id=te1.transaction_id where te1.to_status='payment_secured' and te2.to_status='dispatched' and te1.created_at<te2.created_at and exists(select 1 from transaction_participants tp3 where tp3.transaction_id=te1.transaction_id and tp3.user_id=p_user_id)),
 account_age_days=greatest(0,extract(day from now()-(select created_at from profiles where id=p_user_id))::int),
 identity_verification_status=coalesce((select status from identity_verifications where user_id=p_user_id order by created_at desc limit 1),'pending'),
 calculated_at=now(),updated_at=now() where tp.user_id=p_user_id returning * into r;
 return r;
end $$;
revoke all on function public.refresh_trust_profile(uuid) from public;
grant execute on function public.refresh_trust_profile(uuid) to service_role;
