-- Delivery & Courier Infrastructure
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'courier';
ALTER TYPE public.transaction_status ADD VALUE IF NOT EXISTS 'delivery_exception';

DO $$ BEGIN
  CREATE TYPE public.delivery_status AS ENUM ('draft','ready_for_dispatch','dispatched','picked_up','in_transit','delivery_attempted','delivered','failed','cancelled','returned');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.delivery_event_type AS ENUM ('created','assigned','dispatch_ready','dispatched','pickup_confirmed','in_transit','delivery_attempted','delivery_confirmed','delivery_failed','cancelled','returned','location_recorded');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.courier_profiles (
  user_id uuid PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  courier_code text UNIQUE NOT NULL,
  legal_name text,
  phone text,
  vehicle_type text,
  vehicle_reference text,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','inactive')),
  service_area jsonb NOT NULL DEFAULT '{}'::jsonb,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id uuid NOT NULL UNIQUE REFERENCES public.transactions(id) ON DELETE RESTRICT,
  courier_user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  status public.delivery_status NOT NULL DEFAULT 'draft',
  provider text NOT NULL DEFAULT 'internal',
  provider_delivery_ref text,
  pickup_address jsonb NOT NULL DEFAULT '{}'::jsonb,
  delivery_address jsonb NOT NULL DEFAULT '{}'::jsonb,
  package_count integer NOT NULL DEFAULT 1 CHECK (package_count > 0),
  package_weight_grams integer CHECK (package_weight_grams IS NULL OR package_weight_grams > 0),
  package_dimensions jsonb NOT NULL DEFAULT '{}'::jsonb,
  tracking_reference text UNIQUE,
  delivery_pin_hash text,
  delivery_pin_expires_at timestamptz,
  dispatched_at timestamptz,
  picked_up_at timestamptz,
  delivered_at timestamptz,
  failed_at timestamptz,
  failure_reason text,
  recipient_name text,
  recipient_phone text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.delivery_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  delivery_id uuid NOT NULL REFERENCES public.deliveries(id) ON DELETE RESTRICT,
  transaction_id uuid NOT NULL REFERENCES public.transactions(id) ON DELETE RESTRICT,
  actor_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  event_type public.delivery_event_type NOT NULL,
  from_status public.delivery_status,
  to_status public.delivery_status,
  latitude numeric(9,6),
  longitude numeric(9,6),
  accuracy_m numeric,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  evidence_ids uuid[] NOT NULL DEFAULT '{}',
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  idempotency_key text UNIQUE
);

CREATE TABLE IF NOT EXISTS public.delivery_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  delivery_id uuid NOT NULL REFERENCES public.deliveries(id) ON DELETE RESTRICT,
  courier_user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  assigned_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  accepted_at timestamptz,
  released_at timestamptz,
  status text NOT NULL DEFAULT 'assigned' CHECK (status IN ('assigned','accepted','released','rejected')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.delivery_tracking_points (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  delivery_id uuid NOT NULL REFERENCES public.deliveries(id) ON DELETE RESTRICT,
  courier_user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  latitude numeric(9,6) NOT NULL,
  longitude numeric(9,6) NOT NULL,
  accuracy_m numeric,
  recorded_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS deliveries_status_idx ON public.deliveries(status, updated_at DESC);
CREATE INDEX IF NOT EXISTS deliveries_courier_idx ON public.deliveries(courier_user_id, status, updated_at DESC);
CREATE INDEX IF NOT EXISTS deliveries_transaction_idx ON public.deliveries(transaction_id);
CREATE INDEX IF NOT EXISTS deliveries_tracking_idx ON public.deliveries(tracking_reference);
CREATE INDEX IF NOT EXISTS delivery_events_delivery_time_idx ON public.delivery_events(delivery_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS delivery_events_transaction_time_idx ON public.delivery_events(transaction_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS delivery_events_type_time_idx ON public.delivery_events(event_type, occurred_at DESC);
CREATE INDEX IF NOT EXISTS delivery_assignments_courier_idx ON public.delivery_assignments(courier_user_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS delivery_tracking_delivery_time_idx ON public.delivery_tracking_points(delivery_id, recorded_at DESC);

ALTER TABLE public.courier_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.deliveries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.delivery_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.delivery_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.delivery_tracking_points ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS courier_profile_self_or_staff ON public.courier_profiles;
CREATE POLICY courier_profile_self_or_staff ON public.courier_profiles FOR SELECT USING (user_id=auth.uid() OR public.is_staff(auth.uid()));
DROP POLICY IF EXISTS deliveries_participant_staff_courier ON public.deliveries;
CREATE POLICY deliveries_participant_staff_courier ON public.deliveries FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.transactions t WHERE t.id=transaction_id AND (t.buyer_id=auth.uid() OR t.seller_id=auth.uid()))
  OR courier_user_id=auth.uid() OR public.is_staff(auth.uid())
);
DROP POLICY IF EXISTS delivery_events_participant_staff_courier ON public.delivery_events;
CREATE POLICY delivery_events_participant_staff_courier ON public.delivery_events FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.transactions t WHERE t.id=transaction_id AND (t.buyer_id=auth.uid() OR t.seller_id=auth.uid()))
  OR EXISTS (SELECT 1 FROM public.deliveries d WHERE d.id=delivery_id AND d.courier_user_id=auth.uid()) OR public.is_staff(auth.uid())
);
DROP POLICY IF EXISTS delivery_assignments_staff_courier ON public.delivery_assignments;
CREATE POLICY delivery_assignments_staff_courier ON public.delivery_assignments FOR SELECT USING (courier_user_id=auth.uid() OR public.is_staff(auth.uid()));
DROP POLICY IF EXISTS delivery_tracking_staff_courier_participant ON public.delivery_tracking_points;
CREATE POLICY delivery_tracking_staff_courier_participant ON public.delivery_tracking_points FOR SELECT USING (
  courier_user_id=auth.uid() OR public.is_staff(auth.uid()) OR EXISTS (
    SELECT 1 FROM public.deliveries d JOIN public.transactions t ON t.id=d.transaction_id
    WHERE d.id=delivery_id AND (t.buyer_id=auth.uid() OR t.seller_id=auth.uid())
  )
);

-- Backend transaction state remains financially authoritative: delivery milestones are recorded first,
-- then verified delivery confirmation moves dispatched -> delivered.
CREATE OR REPLACE FUNCTION public.delivery_actor_authorized(p_delivery_id uuid, p_actor_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.deliveries d
    JOIN public.transactions t ON t.id=d.transaction_id
    WHERE d.id=p_delivery_id AND (
      d.courier_user_id=p_actor_id OR t.buyer_id=p_actor_id OR t.seller_id=p_actor_id OR public.is_staff(p_actor_id)
    )
  );
$$;
