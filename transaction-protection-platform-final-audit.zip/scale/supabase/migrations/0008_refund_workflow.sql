DO $$ BEGIN ALTER TYPE public.transaction_status ADD VALUE IF NOT EXISTS 'refund_pending'; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
CREATE TYPE public.refund_request_status AS ENUM ('requested','pending','processing','needs_attention','processed','failed','cancelled');
CREATE TABLE IF NOT EXISTS public.refund_requests(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 transaction_id uuid NOT NULL REFERENCES public.transactions(id) ON DELETE CASCADE,
 dispute_id uuid REFERENCES public.disputes(id) ON DELETE SET NULL,
 payment_id uuid REFERENCES public.payments(id) ON DELETE SET NULL,
 requested_by uuid NOT NULL REFERENCES public.profiles(id),
 amount_minor bigint NOT NULL CHECK(amount_minor>0),
 currency text NOT NULL DEFAULT 'GHS',
 status public.refund_request_status NOT NULL DEFAULT 'requested',
 provider text,
 provider_ref text,
 provider_status text,
 reason text,
 metadata jsonb NOT NULL DEFAULT '{}',
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 processed_at timestamptz
);
CREATE UNIQUE INDEX IF NOT EXISTS refund_one_active_per_tx ON public.refund_requests(transaction_id) WHERE status IN ('requested','pending','processing','needs_attention');
CREATE INDEX IF NOT EXISTS refund_requests_tx_idx ON public.refund_requests(transaction_id,created_at DESC);
ALTER TABLE public.refund_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY refund_requests_case_access ON public.refund_requests FOR SELECT USING(public.case_access_allowed(auth.uid(),transaction_id));

CREATE OR REPLACE FUNCTION public.valid_transaction_transition(old_status public.transaction_status,new_status public.transaction_status)
RETURNS boolean LANGUAGE sql IMMUTABLE AS $$
 SELECT CASE old_status
  WHEN 'created' THEN new_status IN ('specification_pending','cancelled','expired')
  WHEN 'specification_pending' THEN new_status IN ('specification_locked','cancelled','expired')
  WHEN 'specification_locked' THEN new_status IN ('awaiting_payment','specification_pending','cancelled','expired')
  WHEN 'awaiting_payment' THEN new_status IN ('payment_pending','specification_pending','cancelled','expired')
  WHEN 'payment_pending' THEN new_status IN ('payment_secured','awaiting_payment','cancelled','expired')
  WHEN 'payment_secured' THEN new_status IN ('awaiting_dispatch','cancelled','disputed','refunded','refund_pending')
  WHEN 'awaiting_dispatch' THEN new_status IN ('dispatched','disputed','cancelled')
  WHEN 'dispatched' THEN new_status IN ('delivered','disputed')
  WHEN 'delivered' THEN new_status IN ('inspection','disputed')
  WHEN 'inspection' THEN new_status IN ('accepted','disputed')
  WHEN 'accepted' THEN new_status IN ('paid_out','disputed')
  WHEN 'disputed' THEN new_status IN ('resolved','return_pending','refunded','refund_pending','paid_out')
  WHEN 'refund_pending' THEN new_status IN ('refunded','disputed','resolved')
  WHEN 'return_pending' THEN new_status IN ('refunded','resolved','disputed')
  WHEN 'resolved' THEN new_status IN ('refunded','paid_out')
  WHEN 'funded' THEN new_status IN ('awaiting_dispatch','disputed','refunded','refund_pending')
  WHEN 'seller_preparing' THEN new_status IN ('awaiting_dispatch','disputed','cancelled')
  WHEN 'inspection_pending' THEN new_status IN ('accepted','disputed')
  ELSE false END;
$$;

CREATE OR REPLACE FUNCTION public.transition_transaction(transaction_id uuid,actor_id uuid,to_status public.transaction_status,idempotency_key text,metadata jsonb DEFAULT '{}')
RETURNS public.transactions LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE r public.transactions; old_status public.transaction_status;
BEGIN
 SELECT * INTO r FROM public.transactions WHERE id=transaction_id FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Transaction not found'; END IF;
 IF EXISTS(SELECT 1 FROM public.transaction_events WHERE transaction_id=transition_transaction.transaction_id AND idempotency_key=transition_transaction.idempotency_key) THEN RETURN r; END IF;
 IF actor_id IS NOT NULL THEN
   IF actor_id NOT IN (r.buyer_id,r.seller_id) AND NOT public.is_staff(actor_id) THEN RAISE EXCEPTION 'Actor is not authorized'; END IF;
 END IF;
 IF NOT public.valid_transaction_transition(r.status,to_status) THEN RAISE EXCEPTION 'Invalid transaction transition: % -> %',r.status,to_status; END IF;
 IF to_status IN ('payment_secured','paid_out','refunded','refund_pending','resolved') AND actor_id IS NOT NULL AND NOT public.is_staff(actor_id) THEN RAISE EXCEPTION 'Sensitive transaction transition requires backend/staff authorization'; END IF;
 old_status := r.status;
 UPDATE public.transactions SET status=to_status,state_version=state_version+1,state_changed_at=now(),updated_at=now() WHERE id=r.id RETURNING * INTO r;
 INSERT INTO public.transaction_events(transaction_id,actor_id,event_type,from_status,to_status,metadata,idempotency_key) VALUES(r.id,actor_id,'state_transition',old_status,to_status,metadata,idempotency_key);
 RETURN r;
END;
$$;
REVOKE ALL ON FUNCTION public.transition_transaction(uuid,uuid,public.transaction_status,text,jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.transition_transaction(uuid,uuid,public.transaction_status,text,jsonb) TO service_role;
