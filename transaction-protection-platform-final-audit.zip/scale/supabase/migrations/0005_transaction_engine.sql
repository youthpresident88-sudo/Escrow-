-- Production transaction engine: agreement-first lifecycle, specification versioning,
-- category extensibility, participant authorization, and concurrency-safe transitions.


DO $$ BEGIN
  CREATE TYPE public.transaction_participant_role AS ENUM ('buyer','seller','support','risk_analyst','admin');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE public.specification_status AS ENUM ('draft','locked','superseded');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE public.confirmation_status AS ENUM ('confirmed','revoked');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE public.category_field_type AS ENUM ('text','number','boolean','select','multiselect','date','json');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.product_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name text NOT NULL UNIQUE,
  description text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.category_spec_fields (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid NOT NULL REFERENCES public.product_categories(id) ON DELETE CASCADE,
  field_key text NOT NULL,
  label text NOT NULL,
  field_type public.category_field_type NOT NULL,
  required boolean NOT NULL DEFAULT false,
  options jsonb NOT NULL DEFAULT '[]'::jsonb,
  validation jsonb NOT NULL DEFAULT '{}'::jsonb,
  sort_order integer NOT NULL DEFAULT 0 CHECK (sort_order >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(category_id, field_key)
);
CREATE INDEX IF NOT EXISTS category_spec_fields_category_idx ON public.category_spec_fields(category_id, sort_order);

CREATE TABLE IF NOT EXISTS public.transaction_participants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id uuid NOT NULL REFERENCES public.transactions(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  role public.transaction_participant_role NOT NULL,
  joined_at timestamptz NOT NULL DEFAULT now(),
  left_at timestamptz,
  UNIQUE(transaction_id, role),
  UNIQUE(transaction_id, user_id, role)
);
CREATE INDEX IF NOT EXISTS transaction_participants_user_idx ON public.transaction_participants(user_id, transaction_id);

CREATE TABLE IF NOT EXISTS public.transaction_specifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id uuid NOT NULL REFERENCES public.transactions(id) ON DELETE CASCADE,
  version integer NOT NULL CHECK (version > 0),
  category_id uuid REFERENCES public.product_categories(id) ON DELETE RESTRICT,
  product_name text NOT NULL CHECK (length(trim(product_name)) >= 2),
  description text NOT NULL,
  price_minor bigint NOT NULL CHECK (price_minor > 0),
  currency char(3) NOT NULL DEFAULT 'GHS',
  quantity integer NOT NULL CHECK (quantity > 0),
  condition text NOT NULL CHECK (length(trim(condition)) >= 1),
  delivery_terms jsonb NOT NULL DEFAULT '{}'::jsonb,
  return_terms jsonb NOT NULL DEFAULT '{}'::jsonb,
  status public.specification_status NOT NULL DEFAULT 'draft',
  created_by uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  locked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(transaction_id, version)
);
CREATE UNIQUE INDEX IF NOT EXISTS one_current_specification_per_transaction
  ON public.transaction_specifications(transaction_id) WHERE status IN ('draft','locked');
CREATE INDEX IF NOT EXISTS transaction_specifications_tx_idx ON public.transaction_specifications(transaction_id, version DESC);

CREATE TABLE IF NOT EXISTS public.specification_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  specification_id uuid NOT NULL REFERENCES public.transaction_specifications(id) ON DELETE CASCADE,
  field_key text NOT NULL,
  label text NOT NULL,
  value jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(specification_id, field_key)
);
CREATE INDEX IF NOT EXISTS specification_items_spec_idx ON public.specification_items(specification_id);

CREATE TABLE IF NOT EXISTS public.specification_confirmations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  specification_id uuid NOT NULL REFERENCES public.transaction_specifications(id) ON DELETE RESTRICT,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  participant_role public.transaction_participant_role NOT NULL,
  status public.confirmation_status NOT NULL DEFAULT 'confirmed',
  confirmed_at timestamptz NOT NULL DEFAULT now(),
  confirmation_hash text,
  ip inet,
  user_agent text,
  UNIQUE(specification_id, user_id, participant_role)
);
CREATE INDEX IF NOT EXISTS specification_confirmations_spec_idx ON public.specification_confirmations(specification_id, participant_role, status);

ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS category_id uuid REFERENCES public.product_categories(id) ON DELETE RESTRICT;
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS current_specification_id uuid REFERENCES public.transaction_specifications(id) ON DELETE SET NULL;
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS state_changed_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS state_version bigint NOT NULL DEFAULT 1;
CREATE INDEX IF NOT EXISTS transactions_category_idx ON public.transactions(category_id, created_at DESC);

-- Seed only category definitions, not users or transactions. Safe for all environments.
INSERT INTO public.product_categories(slug,name,description) VALUES
 ('phones','Phones','Mobile phones and smartphones'),
 ('laptops','Laptops','Laptops and notebook computers'),
 ('electronics','Electronics','Consumer electronics and accessories'),
 ('clothing','Clothing','Clothing, footwear and fashion items'),
 ('household-goods','Household Goods','Furniture, appliances and household goods'),
 ('vehicles','Vehicles','Cars, motorcycles and other vehicles'),
 ('other','Other','Products not covered by a dedicated category')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO public.category_spec_fields(category_id,field_key,label,field_type,required,sort_order)
SELECT c.id, x.field_key, x.label, x.field_type::public.category_field_type, x.required, x.sort_order
FROM public.product_categories c
JOIN (VALUES
 ('phones','brand','Brand','text',true,10),('phones','model','Model','text',true,20),('phones','storage','Storage','text',false,30),
 ('laptops','brand','Brand','text',true,10),('laptops','model','Model','text',true,20),('laptops','ram','RAM','text',false,30),
 ('electronics','brand','Brand','text',false,10),('electronics','model','Model','text',false,20),
 ('clothing','brand','Brand','text',false,10),('clothing','size','Size','text',true,20),('clothing','material','Material','text',false,30),
 ('household-goods','brand','Brand','text',false,10),('household-goods','model','Model','text',false,20),
 ('vehicles','make','Make','text',true,10),('vehicles','model','Model','text',true,20),('vehicles','year','Year','number',false,30),
 ('other','details','Additional details','json',false,10)
) AS x(slug,field_key,label,field_type,required,sort_order) ON c.slug=x.slug
ON CONFLICT (category_id,field_key) DO NOTHING;

CREATE OR REPLACE FUNCTION public.transaction_participant_role_for(uid uuid, tid uuid)
RETURNS public.transaction_participant_role
LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
  SELECT role FROM public.transaction_participants WHERE transaction_id=tid AND user_id=uid AND left_at IS NULL LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.is_transaction_participant(uid uuid, tid uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
  SELECT EXISTS(SELECT 1 FROM public.transaction_participants WHERE transaction_id=tid AND user_id=uid AND left_at IS NULL);
$$;

CREATE OR REPLACE FUNCTION public.valid_transaction_transition(old_status public.transaction_status, new_status public.transaction_status)
RETURNS boolean LANGUAGE sql IMMUTABLE AS $$
SELECT CASE old_status
 WHEN 'created' THEN new_status IN ('specification_pending','cancelled','expired')
 WHEN 'specification_pending' THEN new_status IN ('specification_locked','cancelled','expired')
 WHEN 'specification_locked' THEN new_status IN ('awaiting_payment','specification_pending','cancelled','expired')
 WHEN 'awaiting_payment' THEN new_status IN ('payment_pending','specification_pending','cancelled','expired')
 WHEN 'payment_pending' THEN new_status IN ('payment_secured','awaiting_payment','cancelled','expired')
 WHEN 'payment_secured' THEN new_status IN ('awaiting_dispatch','cancelled','disputed','refunded')
 WHEN 'awaiting_dispatch' THEN new_status IN ('dispatched','disputed','cancelled')
 WHEN 'dispatched' THEN new_status IN ('delivered','disputed')
 WHEN 'delivered' THEN new_status IN ('inspection','disputed')
 WHEN 'inspection' THEN new_status IN ('accepted','disputed')
 WHEN 'accepted' THEN new_status IN ('paid_out','disputed')
 WHEN 'disputed' THEN new_status IN ('resolved','return_pending','refunded','paid_out')
 WHEN 'return_pending' THEN new_status IN ('refunded','resolved','disputed')
 WHEN 'resolved' THEN new_status IN ('refunded','paid_out')
 WHEN 'funded' THEN new_status IN ('awaiting_dispatch','disputed','refunded')
 WHEN 'seller_preparing' THEN new_status IN ('awaiting_dispatch','disputed','cancelled')
 WHEN 'inspection_pending' THEN new_status IN ('accepted','disputed')
 ELSE false END;
$$;

CREATE OR REPLACE FUNCTION public.transition_transaction(
  p_transaction_id uuid,
  p_actor_id uuid,
  p_to_status public.transaction_status,
  p_idempotency_key text,
  p_metadata jsonb DEFAULT '{}'::jsonb
) RETURNS public.transactions
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE
  t public.transactions;
  existing public.transaction_events;
  role public.transaction_participant_role;
BEGIN
  SELECT * INTO t FROM public.transactions WHERE id=p_transaction_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Transaction not found' USING ERRCODE='P0002'; END IF;

  role := public.transaction_participant_role_for(p_actor_id,p_transaction_id);
  IF p_actor_id IS NOT NULL AND role IS NULL AND NOT public.is_staff(p_actor_id) THEN
    RAISE EXCEPTION 'Actor is not authorized for this transaction' USING ERRCODE='42501';
  END IF;

  IF p_idempotency_key IS NOT NULL THEN
    SELECT * INTO existing FROM public.transaction_events
    WHERE transaction_id=p_transaction_id AND idempotency_key=p_idempotency_key LIMIT 1;
    IF FOUND THEN SELECT * INTO t FROM public.transactions WHERE id=p_transaction_id; RETURN t; END IF;
  END IF;

  IF NOT public.valid_transaction_transition(t.status,p_to_status) THEN
    RAISE EXCEPTION 'Invalid transaction transition: % -> %', t.status, p_to_status USING ERRCODE='P0001';
  END IF;

  -- Participants cannot arbitrarily force sensitive financial/resolution transitions.
  IF p_actor_id IS NOT NULL AND NOT public.is_staff(p_actor_id) THEN
    IF p_to_status IN ('payment_secured','paid_out','refunded','resolved') THEN
      RAISE EXCEPTION 'Only authorized backend operations can perform this transition' USING ERRCODE='42501';
    END IF;
  END IF;

  UPDATE public.transactions
  SET status=p_to_status, version=version+1, state_version=state_version+1,
      state_changed_at=now(), updated_at=now()
  WHERE id=p_transaction_id;

  INSERT INTO public.transaction_events(transaction_id,actor_id,event_type,from_status,to_status,metadata,idempotency_key)
  VALUES(p_transaction_id,p_actor_id,'transaction.state_changed',t.status,p_to_status,p_metadata,p_idempotency_key);

  SELECT * INTO t FROM public.transactions WHERE id=p_transaction_id;
  RETURN t;
END;
$$;

CREATE OR REPLACE FUNCTION public.prevent_locked_specification_mutation()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF OLD.status='locked' AND NEW.status='superseded' THEN RETURN NEW; END IF;
  IF OLD.status='locked' THEN RAISE EXCEPTION 'Locked specifications are immutable; create an amendment version'; END IF;
  IF OLD.status='superseded' THEN RAISE EXCEPTION 'Superseded specifications are immutable'; END IF;
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS prevent_locked_specification_update ON public.transaction_specifications;
CREATE TRIGGER prevent_locked_specification_update BEFORE UPDATE ON public.transaction_specifications
FOR EACH ROW EXECUTE FUNCTION public.prevent_locked_specification_mutation();

CREATE OR REPLACE FUNCTION public.prevent_locked_specification_delete()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF OLD.status IN ('locked','superseded') THEN RAISE EXCEPTION 'Locked/superseded specifications cannot be deleted'; END IF;
  RETURN OLD;
END;
$$;
DROP TRIGGER IF EXISTS prevent_locked_specification_delete ON public.transaction_specifications;
CREATE TRIGGER prevent_locked_specification_delete BEFORE DELETE ON public.transaction_specifications
FOR EACH ROW EXECUTE FUNCTION public.prevent_locked_specification_delete();

ALTER TABLE public.product_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.category_spec_fields ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transaction_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transaction_specifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.specification_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.specification_confirmations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS categories_read ON public.product_categories;
CREATE POLICY categories_read ON public.product_categories FOR SELECT USING (is_active OR public.is_staff(auth.uid()));
DROP POLICY IF EXISTS category_fields_read ON public.category_spec_fields;
CREATE POLICY category_fields_read ON public.category_spec_fields FOR SELECT USING (EXISTS(SELECT 1 FROM public.product_categories c WHERE c.id=category_id AND (c.is_active OR public.is_staff(auth.uid()))));
DROP POLICY IF EXISTS participants_read ON public.transaction_participants;
CREATE POLICY participants_read ON public.transaction_participants FOR SELECT USING (user_id=auth.uid() OR public.is_transaction_participant(auth.uid(),transaction_id) OR public.is_staff(auth.uid()));
DROP POLICY IF EXISTS specifications_read ON public.transaction_specifications;
CREATE POLICY specifications_read ON public.transaction_specifications FOR SELECT USING (public.is_transaction_participant(auth.uid(),transaction_id) OR public.is_staff(auth.uid()));
DROP POLICY IF EXISTS specification_items_read ON public.specification_items;
CREATE POLICY specification_items_read ON public.specification_items FOR SELECT USING (EXISTS(SELECT 1 FROM public.transaction_specifications s WHERE s.id=specification_id AND (public.is_transaction_participant(auth.uid(),s.transaction_id) OR public.is_staff(auth.uid()))));
DROP POLICY IF EXISTS specification_confirmations_read ON public.specification_confirmations;
CREATE POLICY specification_confirmations_read ON public.specification_confirmations FOR SELECT USING (user_id=auth.uid() OR EXISTS(SELECT 1 FROM public.transaction_specifications s WHERE s.id=specification_id AND public.is_transaction_participant(auth.uid(),s.transaction_id)) OR public.is_staff(auth.uid()));

-- Existing foundation's transaction RLS remains compatible with the seller-created flow.
-- Keep buyer/seller foreign keys synchronized with participant rows at creation/update time.
CREATE OR REPLACE FUNCTION public.sync_transaction_participants()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  INSERT INTO public.transaction_participants(transaction_id,user_id,role)
  VALUES(NEW.id,NEW.buyer_id,'buyer'),(NEW.id,NEW.seller_id,'seller')
  ON CONFLICT(transaction_id,role) DO UPDATE SET user_id=EXCLUDED.user_id;
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS sync_transaction_participants_trigger ON public.transactions;
CREATE TRIGGER sync_transaction_participants_trigger AFTER INSERT OR UPDATE OF buyer_id,seller_id ON public.transactions
FOR EACH ROW EXECUTE FUNCTION public.sync_transaction_participants();

-- Keep current_specification_id valid and ensure it belongs to the same transaction.
CREATE OR REPLACE FUNCTION public.validate_current_specification()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.current_specification_id IS NOT NULL AND NOT EXISTS(
    SELECT 1 FROM public.transaction_specifications s WHERE s.id=NEW.current_specification_id AND s.transaction_id=NEW.id
  ) THEN RAISE EXCEPTION 'Current specification must belong to transaction'; END IF;
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS validate_current_specification_trigger ON public.transactions;
CREATE TRIGGER validate_current_specification_trigger BEFORE INSERT OR UPDATE ON public.transactions
FOR EACH ROW EXECUTE FUNCTION public.validate_current_specification();

REVOKE ALL ON FUNCTION public.transition_transaction(uuid,uuid,public.transaction_status,text,jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.transition_transaction(uuid,uuid,public.transaction_status,text,jsonb) TO service_role;
