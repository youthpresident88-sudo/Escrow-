-- Final production security hardening.
-- Service-role workers/API may write operational records; authenticated clients receive only explicit read policies.

ALTER TABLE public.delivery_events
  DROP CONSTRAINT IF EXISTS delivery_events_latitude_check,
  DROP CONSTRAINT IF EXISTS delivery_events_longitude_check,
  DROP CONSTRAINT IF EXISTS delivery_events_accuracy_check;
ALTER TABLE public.delivery_events
  ADD CONSTRAINT delivery_events_latitude_check CHECK (latitude IS NULL OR latitude BETWEEN -90 AND 90),
  ADD CONSTRAINT delivery_events_longitude_check CHECK (longitude IS NULL OR longitude BETWEEN -180 AND 180),
  ADD CONSTRAINT delivery_events_accuracy_check CHECK (accuracy_m IS NULL OR accuracy_m >= 0);

ALTER TABLE public.delivery_tracking_points
  DROP CONSTRAINT IF EXISTS delivery_tracking_latitude_check,
  DROP CONSTRAINT IF EXISTS delivery_tracking_longitude_check,
  DROP CONSTRAINT IF EXISTS delivery_tracking_accuracy_check;
ALTER TABLE public.delivery_tracking_points
  ADD CONSTRAINT delivery_tracking_latitude_check CHECK (latitude BETWEEN -90 AND 90),
  ADD CONSTRAINT delivery_tracking_longitude_check CHECK (longitude BETWEEN -180 AND 180),
  ADD CONSTRAINT delivery_tracking_accuracy_check CHECK (accuracy_m IS NULL OR accuracy_m >= 0);

CREATE UNIQUE INDEX IF NOT EXISTS delivery_one_active_assignment_idx
  ON public.delivery_assignments(delivery_id)
  WHERE status IN ('assigned','accepted');

CREATE INDEX IF NOT EXISTS delivery_tracking_courier_time_idx
  ON public.delivery_tracking_points(courier_user_id, recorded_at DESC, id DESC);

-- Read-only reference data for authenticated users; writes remain service-role only.
ALTER TABLE public.inspection_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inspection_template_items ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS inspection_templates_authenticated_read ON public.inspection_templates;
CREATE POLICY inspection_templates_authenticated_read ON public.inspection_templates
  FOR SELECT USING (auth.uid() IS NOT NULL);
DROP POLICY IF EXISTS inspection_template_items_authenticated_read ON public.inspection_template_items;
CREATE POLICY inspection_template_items_authenticated_read ON public.inspection_template_items
  FOR SELECT USING (auth.uid() IS NOT NULL);

-- Cold/archive tables are never directly writable by authenticated clients.
ALTER TABLE public.archive_runs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_log_archive ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transaction_events_archive ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS archive_runs_staff_read ON public.archive_runs;
CREATE POLICY archive_runs_staff_read ON public.archive_runs FOR SELECT USING (public.is_staff(auth.uid()));
DROP POLICY IF EXISTS audit_archive_staff_read ON public.audit_log_archive;
CREATE POLICY audit_archive_staff_read ON public.audit_log_archive FOR SELECT USING (public.is_staff(auth.uid()));
DROP POLICY IF EXISTS transaction_events_archive_staff_read ON public.transaction_events_archive;
CREATE POLICY transaction_events_archive_staff_read ON public.transaction_events_archive FOR SELECT USING (public.is_staff(auth.uid()));

-- Administrative/audit records are append-only. Corrections are new records, never UPDATE/DELETE.
CREATE OR REPLACE FUNCTION public.prevent_audit_mutation() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'Audit records are append-only';
END $$;
DROP TRIGGER IF EXISTS audit_log_append_only ON public.audit_log;
CREATE TRIGGER audit_log_append_only BEFORE UPDATE OR DELETE ON public.audit_log
FOR EACH ROW EXECUTE FUNCTION public.prevent_audit_mutation();
DROP TRIGGER IF EXISTS operations_action_log_append_only ON public.operations_action_log;
CREATE TRIGGER operations_action_log_append_only BEFORE UPDATE OR DELETE ON public.operations_action_log
FOR EACH ROW EXECUTE FUNCTION public.prevent_audit_mutation();

-- Protect delivery records from direct client writes; the API/service role is the write boundary.
DROP POLICY IF EXISTS deliveries_client_write ON public.deliveries;
DROP POLICY IF EXISTS delivery_events_client_write ON public.delivery_events;
DROP POLICY IF EXISTS delivery_assignments_client_write ON public.delivery_assignments;
DROP POLICY IF EXISTS delivery_tracking_client_write ON public.delivery_tracking_points;

REVOKE ALL ON FUNCTION public.delivery_actor_authorized(uuid,uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.delivery_actor_authorized(uuid,uuid) TO service_role;
