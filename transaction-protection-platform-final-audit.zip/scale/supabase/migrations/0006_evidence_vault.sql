-- Production Evidence Vault
DO $$ BEGIN ALTER TYPE public.evidence_type ADD VALUE IF NOT EXISTS 'seller_condition_photo'; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TYPE public.evidence_type ADD VALUE IF NOT EXISTS 'serial_imei'; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TYPE public.evidence_type ADD VALUE IF NOT EXISTS 'packaging'; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TYPE public.evidence_type ADD VALUE IF NOT EXISTS 'pickup'; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TYPE public.evidence_type ADD VALUE IF NOT EXISTS 'delivery_confirmation'; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TYPE public.evidence_type ADD VALUE IF NOT EXISTS 'inspection_video'; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TYPE public.evidence_type ADD VALUE IF NOT EXISTS 'problem'; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TYPE public.evidence_type ADD VALUE IF NOT EXISTS 'return_packaging'; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TYPE public.evidence_type ADD VALUE IF NOT EXISTS 'return_dispatch'; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TYPE public.evidence_type ADD VALUE IF NOT EXISTS 'return_receipt'; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TYPE public.evidence_type ADD VALUE IF NOT EXISTS 'return_inspection'; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TYPE public.evidence_type ADD VALUE IF NOT EXISTS 'dispute_supporting'; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TYPE public.evidence_type ADD VALUE IF NOT EXISTS 'dispute_additional'; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER TYPE public.evidence_type ADD VALUE IF NOT EXISTS 'expert'; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TYPE public.evidence_upload_status AS ENUM ('pending','uploaded','verified','failed','expired');
CREATE TYPE public.evidence_event_type AS ENUM ('capture_started','capture_completed','upload_created','upload_started','upload_completed','hash_calculated','verified','accessed','downloaded','version_created','superseded','upload_failed','upload_expired');

ALTER TABLE public.evidence
  ADD COLUMN IF NOT EXISTS version_no integer NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS supersedes_id uuid REFERENCES public.evidence(id),
  ADD COLUMN IF NOT EXISTS is_current boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS original_filename text,
  ADD COLUMN IF NOT EXISTS file_extension text,
  ADD COLUMN IF NOT EXISTS dimensions jsonb,
  ADD COLUMN IF NOT EXISTS duration_ms bigint,
  ADD COLUMN IF NOT EXISTS device_info jsonb NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS capture_metadata jsonb NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS upload_completed_at timestamptz,
  ADD COLUMN IF NOT EXISTS verified_at timestamptz,
  ADD COLUMN IF NOT EXISTS privacy_classification text NOT NULL DEFAULT 'transaction_evidence';

CREATE INDEX IF NOT EXISTS evidence_current_idx ON public.evidence(transaction_id, is_current, created_at DESC);
CREATE INDEX IF NOT EXISTS evidence_supersedes_idx ON public.evidence(supersedes_id);
CREATE UNIQUE INDEX IF NOT EXISTS evidence_one_current_version ON public.evidence(transaction_id, supersedes_id, version_no) WHERE is_current;

CREATE TABLE IF NOT EXISTS public.evidence_uploads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id uuid NOT NULL REFERENCES public.transactions(id) ON DELETE CASCADE,
  evidence_id uuid REFERENCES public.evidence(id) ON DELETE SET NULL,
  uploader_id uuid NOT NULL REFERENCES public.profiles(id),
  type public.evidence_type NOT NULL,
  storage_path text NOT NULL UNIQUE,
  original_filename text,
  mime_type text NOT NULL,
  expected_byte_size bigint NOT NULL CHECK(expected_byte_size > 0),
  expected_sha256 text CHECK(expected_sha256 IS NULL OR length(expected_sha256)=64),
  upload_token_expires_at timestamptz,
  status public.evidence_upload_status NOT NULL DEFAULT 'pending',
  error_message text,
  metadata jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS evidence_uploads_tx_idx ON public.evidence_uploads(transaction_id, created_at DESC);

CREATE TABLE IF NOT EXISTS public.evidence_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id uuid NOT NULL REFERENCES public.transactions(id) ON DELETE CASCADE,
  evidence_id uuid REFERENCES public.evidence(id) ON DELETE SET NULL,
  upload_id uuid REFERENCES public.evidence_uploads(id) ON DELETE SET NULL,
  actor_id uuid REFERENCES public.profiles(id),
  event_type public.evidence_event_type NOT NULL,
  metadata jsonb NOT NULL DEFAULT '{}',
  occurred_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS evidence_events_timeline_idx ON public.evidence_events(transaction_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS evidence_events_evidence_idx ON public.evidence_events(evidence_id, occurred_at DESC);

CREATE OR REPLACE FUNCTION public.evidence_access_allowed(uid uuid, tid uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.transactions t
    WHERE t.id=tid AND (t.buyer_id=uid OR t.seller_id=uid OR public.is_staff(uid))
  );
$$;
REVOKE ALL ON FUNCTION public.evidence_access_allowed(uuid,uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.evidence_access_allowed(uuid,uuid) TO authenticated, service_role;

ALTER TABLE public.evidence_uploads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.evidence_events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS evidence_uploads_participant ON public.evidence_uploads;
CREATE POLICY evidence_uploads_participant ON public.evidence_uploads FOR SELECT USING (public.evidence_access_allowed(auth.uid(), transaction_id));
DROP POLICY IF EXISTS evidence_events_participant ON public.evidence_events;
CREATE POLICY evidence_events_participant ON public.evidence_events FOR SELECT USING (public.evidence_access_allowed(auth.uid(), transaction_id));

-- Storage is private. Application authorization issues short-lived signed URLs.
INSERT INTO storage.buckets (id, name, public)
VALUES ('transaction-evidence','transaction-evidence',false)
ON CONFLICT (id) DO UPDATE SET public=false;

CREATE OR REPLACE FUNCTION public.touch_evidence_upload_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN NEW.updated_at=now(); RETURN NEW; END $$;
DROP TRIGGER IF EXISTS evidence_uploads_touch ON public.evidence_uploads;
CREATE TRIGGER evidence_uploads_touch BEFORE UPDATE ON public.evidence_uploads FOR EACH ROW EXECUTE FUNCTION public.touch_evidence_upload_updated_at();
