create extension if not exists citext;

do $$ begin create type public.identity_verification_status as enum ('pending','verified','rejected','expired'); exception when duplicate_object then null; end $$;
do $$ begin create type public.identity_verification_method as enum ('email','phone','government_id'); exception when duplicate_object then null; end $$;
do $$ begin create type public.session_status as enum ('active','revoked','expired'); exception when duplicate_object then null; end $$;

alter table public.profiles add column if not exists email citext;
alter table public.profiles add column if not exists email_verified_at timestamptz;
alter table public.profiles add column if not exists phone_verified_at timestamptz;
alter table public.profiles add column if not exists deleted_at timestamptz;
alter table public.profiles add column if not exists last_login_at timestamptz;
alter table public.profiles add column if not exists last_login_ip inet;

create table if not exists public.buyer_profiles(
  user_id uuid primary key references public.profiles(id) on delete cascade,
  preferred_currency char(3) not null default 'GHS',
  default_delivery_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.seller_profiles(
  user_id uuid primary key references public.profiles(id) on delete cascade,
  business_name text,
  business_description text,
  country_code char(2) not null default 'GH',
  verification_status public.identity_verification_status not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.identity_verifications(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  method public.identity_verification_method not null,
  provider text not null,
  provider_reference text,
  status public.identity_verification_status not null default 'pending',
  verified_at timestamptz,
  expires_at timestamptz,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(provider,provider_reference)
);
create index if not exists identity_verifications_user_idx on public.identity_verifications(user_id,created_at desc);

create table if not exists public.auth_sessions(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  provider_session_id uuid not null unique,
  status public.session_status not null default 'active',
  device_name text,
  device_type text,
  user_agent text,
  ip inet,
  last_seen_at timestamptz not null default now(),
  expires_at timestamptz,
  revoked_at timestamptz,
  revoked_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists auth_sessions_user_idx on public.auth_sessions(user_id,status,last_seen_at desc);

create table if not exists public.auth_events(
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  event_type text not null,
  success boolean not null,
  ip inet,
  user_agent text,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);
create index if not exists auth_events_user_idx on public.auth_events(user_id,created_at desc);
create index if not exists auth_events_ip_idx on public.auth_events(ip,created_at desc);

create table if not exists public.auth_rate_limits(
  key text primary key,
  attempts integer not null default 0,
  window_started_at timestamptz not null default now(),
  blocked_until timestamptz,
  updated_at timestamptz not null default now()
);

alter table public.buyer_profiles enable row level security;
alter table public.seller_profiles enable row level security;
alter table public.identity_verifications enable row level security;
alter table public.auth_sessions enable row level security;
alter table public.auth_events enable row level security;
alter table public.auth_rate_limits enable row level security;

create policy buyer_profile_self on public.buyer_profiles for all using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy seller_profile_self on public.seller_profiles for select using(user_id=auth.uid() or public.is_staff(auth.uid()));
create policy seller_profile_self_update on public.seller_profiles for update using(user_id=auth.uid() or public.is_staff(auth.uid())) with check(user_id=auth.uid() or public.is_staff(auth.uid()));
create policy identity_verification_self on public.identity_verifications for select using(user_id=auth.uid() or public.is_staff(auth.uid()));
create policy auth_sessions_self on public.auth_sessions for select using(user_id=auth.uid() or public.is_staff(auth.uid()));
create policy auth_events_staff on public.auth_events for select using(public.is_staff(auth.uid()));

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,display_name,phone,email,email_verified_at,phone_verified_at)
  values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''),new.phone,new.email,
    case when new.email_confirmed_at is not null then new.email_confirmed_at end,
    case when new.phone_confirmed_at is not null then new.phone_confirmed_at end)
  on conflict(id) do update set
    email=excluded.email,
    phone=excluded.phone,
    email_verified_at=excluded.email_verified_at,
    phone_verified_at=excluded.phone_verified_at,
    updated_at=now();
  insert into public.buyer_profiles(user_id) values(new.id) on conflict do nothing;
  insert into public.user_roles(user_id,role) values(new.id,'buyer') on conflict do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert or update of email,phone,email_confirmed_at,phone_confirmed_at on auth.users for each row execute function public.handle_new_user();

create or replace function public.prevent_sensitive_user_role_self_grant() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is not null and new.role in ('support','risk_analyst','admin','super_admin') and not public.is_staff(auth.uid()) then
    raise exception 'Privileged roles can only be assigned by authorized staff';
  end if;
  return new;
end $$;
drop trigger if exists protect_user_role_assignment on public.user_roles;
create trigger protect_user_role_assignment before insert or update on public.user_roles for each row execute function public.prevent_sensitive_user_role_self_grant();

create or replace function public.touch_auth_session() returns trigger language plpgsql as $$ begin new.updated_at=now(); return new; end $$;
drop trigger if exists auth_sessions_touch on public.auth_sessions;
create trigger auth_sessions_touch before update on public.auth_sessions for each row execute function public.touch_auth_session();
