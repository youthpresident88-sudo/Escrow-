create type public.notification_status as enum ('queued','processing','accepted','delivered','failed','dead_letter','cancelled');
create type public.notification_preference_level as enum ('enabled','disabled');

create table if not exists public.notification_preferences(
 user_id uuid primary key references public.profiles(id) on delete cascade,
 email public.notification_preference_level not null default 'enabled',
 sms public.notification_preference_level not null default 'enabled',
 push public.notification_preference_level not null default 'enabled',
 in_app public.notification_preference_level not null default 'enabled',
 security_email boolean not null default true,
 security_sms boolean not null default true,
 updated_at timestamptz not null default now()
);

create table if not exists public.notifications(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 event_key text not null,
 channel text not null check(channel in ('sms','email','push','in_app')),
 template text not null,
 provider text,
 provider_message_id text,
 status public.notification_status not null default 'queued',
 payload jsonb not null default '{}',
 failure_reason text,
 retry_count integer not null default 0,
 idempotency_key text not null unique,
 created_at timestamptz not null default now(),
 accepted_at timestamptz,
 delivered_at timestamptz,
 failed_at timestamptz,
 updated_at timestamptz not null default now()
);
create index if not exists notifications_user_idx on public.notifications(user_id,created_at desc);
create index if not exists notifications_status_idx on public.notifications(status,created_at);
create unique index if not exists notifications_provider_message_unique on public.notifications(provider,provider_message_id) where provider_message_id is not null;

create table if not exists public.push_subscriptions(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 endpoint text not null unique,
 p256dh text not null,
 auth text not null,
 user_agent text,
 created_at timestamptz not null default now(),
 last_used_at timestamptz
);

alter table public.notification_outbox add column if not exists event_key text;
alter table public.notification_outbox add column if not exists provider text;
alter table public.notification_outbox add column if not exists provider_message_id text;
alter table public.notification_outbox add column if not exists delivered_at timestamptz;
alter table public.notification_outbox add column if not exists dead_lettered_at timestamptz;
alter table public.notification_outbox drop constraint if exists notification_outbox_status_check;
alter table public.notification_outbox add constraint notification_outbox_status_check check(status in ('pending','processing','sent','failed','dead_letter','cancelled'));

create table if not exists public.notification_provider_events(
 id uuid primary key default gen_random_uuid(),
 provider text not null,
 provider_event_id text not null,
 event_type text not null,
 notification_id uuid references public.notifications(id) on delete set null,
 payload jsonb not null default '{}',
 created_at timestamptz not null default now(),
 unique(provider,provider_event_id)
);

alter table public.notification_preferences enable row level security;
alter table public.notifications enable row level security;
alter table public.push_subscriptions enable row level security;
alter table public.notification_provider_events enable row level security;
create policy notification_preferences_self on public.notification_preferences for all using(user_id=auth.uid() or public.is_staff(auth.uid())) with check(user_id=auth.uid() or public.is_staff(auth.uid()));
create policy notifications_self on public.notifications for select using(user_id=auth.uid() or public.is_staff(auth.uid()));
create policy push_subscriptions_self on public.push_subscriptions for all using(user_id=auth.uid() or public.is_staff(auth.uid())) with check(user_id=auth.uid() or public.is_staff(auth.uid()));
create policy notification_provider_events_staff on public.notification_provider_events for select using(public.is_staff(auth.uid()));

create or replace function public.ensure_notification_preferences() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.notification_preferences(user_id) values(new.id) on conflict do nothing; return new; end $$;
drop trigger if exists trg_profile_notification_preferences on public.profiles;
create trigger trg_profile_notification_preferences after insert on public.profiles for each row execute function public.ensure_notification_preferences();
alter table public.notification_outbox add column if not exists notification_id uuid references public.notifications(id) on delete cascade;
create table if not exists public.notification_dispatch_events(
 id uuid primary key default gen_random_uuid(), source_type text not null, source_id uuid not null, created_at timestamptz not null default now(), unique(source_type,source_id)
);
create index if not exists notification_dispatch_events_source_idx on public.notification_dispatch_events(source_type,source_id);
