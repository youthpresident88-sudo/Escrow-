-- Bind payout destinations to the seller account. Client requests may never choose an arbitrary
-- provider recipient code at payout time.
CREATE TABLE IF NOT EXISTS public.seller_payout_recipients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  provider text NOT NULL DEFAULT 'paystack',
  provider_recipient_code text NOT NULL,
  account_name text,
  account_last4 text,
  bank_code text,
  currency char(3) NOT NULL DEFAULT 'GHS',
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','disabled')),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(provider, provider_recipient_code)
);
CREATE INDEX IF NOT EXISTS seller_payout_recipients_seller_idx
  ON public.seller_payout_recipients(seller_id,status,created_at DESC);
ALTER TABLE public.seller_payout_recipients ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS seller_payout_recipients_self ON public.seller_payout_recipients;
CREATE POLICY seller_payout_recipients_self ON public.seller_payout_recipients
  FOR SELECT USING (seller_id=auth.uid() OR public.is_staff(auth.uid()));
