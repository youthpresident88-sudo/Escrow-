-- Production operations/admin platform
alter type public.app_role add value if not exists 'operations';
alter type public.app_role add value if not exists 'dispute_reviewer';
alter type public.app_role add value if not exists 'finance';
alter type public.app_role add value if not exists 'compliance';

create table if not exists public.support_cases(
 id uuid primary key default gen_random_uuid(),
 user_id uuid references public.profiles(id) on delete set null,
 transaction_id uuid references public.transactions(id) on delete set null,
 status text not null default 'open',
 priority text not null default 'normal',
 subject text not null,
 description text,
 assigned_to uuid references public.profiles(id) on delete set null,
 created_by uuid references public.profiles(id) on delete set null,
 resolved_by uuid references public.profiles(id) on delete set null,
 resolution text,
 resolved_at timestamptz,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create index if not exists support_cases_status_idx on public.support_cases(status,priority,created_at desc);
create index if not exists support_cases_assignee_idx on public.support_cases(assigned_to,status);

create table if not exists public.operations_action_log(
 id uuid primary key default gen_random_uuid(),
 actor_id uuid not null references public.profiles(id) on delete restrict,
 action text not null,
 resource_type text not null,
 resource_id uuid,
 request_id text,
 ip inet,
 user_agent text,
 metadata jsonb not null default '{}',
 created_at timestamptz not null default now()
);
create index if not exists operations_action_log_actor_idx on public.operations_action_log(actor_id,created_at desc);
create index if not exists operations_action_log_resource_idx on public.operations_action_log(resource_type,resource_id,created_at desc);

alter table public.support_cases enable row level security;
alter table public.operations_action_log enable row level security;
create policy support_cases_staff on public.support_cases for all using(public.is_staff(auth.uid())) with check(public.is_staff(auth.uid()));
create policy operations_action_log_staff on public.operations_action_log for select using(public.is_staff(auth.uid()));

create or replace function public.prevent_evidence_mutation() returns trigger language plpgsql as $$
begin
 if current_setting('app.evidence_versioning', true) <> 'true' then
   raise exception 'Historical evidence is immutable; create a new evidence version instead';
 end if;
 return new;
end $$;

drop trigger if exists evidence_staff_immutable on public.evidence;
create trigger evidence_staff_immutable before update or delete on public.evidence for each row execute function public.prevent_evidence_mutation();

create or replace function public.is_staff(uid uuid) returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.user_roles where user_id=uid and role in ('support','risk_analyst','admin','super_admin','operations','dispute_reviewer','finance','compliance')) $$;
