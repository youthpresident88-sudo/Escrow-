-- Production scale/reliability hardening.
-- Keep large immutable/event tables append-only; archive cold data out of hot paths.

CREATE INDEX IF NOT EXISTS transaction_events_type_time_idx ON public.transaction_events(event_type, occurred_at DESC);
CREATE INDEX IF NOT EXISTS evidence_events_type_time_idx ON public.evidence_events(event_type, occurred_at DESC);
CREATE INDEX IF NOT EXISTS evidence_uploads_ready_idx ON public.evidence_uploads(status, created_at) WHERE status IN ('pending','uploaded');
CREATE INDEX IF NOT EXISTS payments_reconciliation_idx ON public.payments(status, updated_at, id);
CREATE INDEX IF NOT EXISTS payment_events_provider_time_idx ON public.payment_events(provider, created_at DESC);
CREATE INDEX IF NOT EXISTS webhook_events_unprocessed_idx ON public.webhook_events(received_at) WHERE processed_at IS NULL;
CREATE INDEX IF NOT EXISTS audit_log_created_idx ON public.audit_log(created_at DESC);
CREATE INDEX IF NOT EXISTS notifications_unread_idx ON public.notifications(user_id, created_at DESC) WHERE read_at IS NULL;

-- Durable worker queue. PostgreSQL SKIP LOCKED provides horizontal worker scaling
-- without introducing a second source of truth for critical jobs.
DO $$ BEGIN CREATE TYPE public.job_status AS ENUM ('queued','processing','succeeded','failed','dead_letter'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
CREATE TABLE IF NOT EXISTS public.jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  queue text NOT NULL,
  job_type text NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}',
  idempotency_key text NOT NULL UNIQUE,
  status public.job_status NOT NULL DEFAULT 'queued',
  attempts integer NOT NULL DEFAULT 0,
  available_at timestamptz NOT NULL DEFAULT now(),
  locked_at timestamptz,
  locked_by text,
  last_error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);
CREATE INDEX IF NOT EXISTS jobs_ready_idx ON public.jobs(queue, available_at, created_at) WHERE status='queued';
CREATE INDEX IF NOT EXISTS jobs_processing_idx ON public.jobs(queue, locked_at) WHERE status='processing';

-- Immutable archival targets. A scheduled archival job can move records older than
-- the configured retention window from hot tables to these append-only tables.
CREATE TABLE IF NOT EXISTS public.audit_log_archive (LIKE public.audit_log INCLUDING ALL);
CREATE TABLE IF NOT EXISTS public.transaction_events_archive (LIKE public.transaction_events INCLUDING ALL);
CREATE INDEX IF NOT EXISTS audit_log_archive_created_idx ON public.audit_log_archive(created_at DESC);
CREATE INDEX IF NOT EXISTS transaction_events_archive_occurred_idx ON public.transaction_events_archive(occurred_at DESC);

CREATE TABLE IF NOT EXISTS public.archive_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  table_name text NOT NULL,
  cutoff_at timestamptz NOT NULL,
  rows_archived bigint NOT NULL DEFAULT 0,
  started_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  error text
);

-- Operational safeguards for connection pooling and long-running statements.
ALTER TABLE public.jobs ENABLE ROW LEVEL SECURITY;
CREATE POLICY jobs_staff_read ON public.jobs FOR SELECT USING (public.is_staff(auth.uid()));

CREATE OR REPLACE FUNCTION public.claim_jobs(p_queue text, p_worker text, p_limit integer DEFAULT 50)
RETURNS SETOF public.jobs
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  RETURN QUERY
  WITH claimed AS (
    SELECT id FROM public.jobs
    WHERE queue=p_queue AND status='queued' AND available_at<=now()
    ORDER BY available_at, created_at
    FOR UPDATE SKIP LOCKED
    LIMIT GREATEST(1, LEAST(p_limit, 500))
  )
  UPDATE public.jobs j
  SET status='processing', attempts=j.attempts+1, locked_at=now(), locked_by=p_worker
  FROM claimed c WHERE j.id=c.id
  RETURNING j.*;
END $$;
REVOKE ALL ON FUNCTION public.claim_jobs(text,text,integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.claim_jobs(text,text,integer) TO service_role;
