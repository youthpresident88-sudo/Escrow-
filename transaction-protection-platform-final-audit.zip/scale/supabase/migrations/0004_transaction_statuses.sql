ALTER TYPE public.transaction_status ADD VALUE IF NOT EXISTS 'created';
ALTER TYPE public.transaction_status ADD VALUE IF NOT EXISTS 'specification_pending';
ALTER TYPE public.transaction_status ADD VALUE IF NOT EXISTS 'specification_locked';
ALTER TYPE public.transaction_status ADD VALUE IF NOT EXISTS 'payment_secured';
ALTER TYPE public.transaction_status ADD VALUE IF NOT EXISTS 'awaiting_dispatch';
ALTER TYPE public.transaction_status ADD VALUE IF NOT EXISTS 'inspection';
ALTER TYPE public.transaction_status ADD VALUE IF NOT EXISTS 'resolved';
