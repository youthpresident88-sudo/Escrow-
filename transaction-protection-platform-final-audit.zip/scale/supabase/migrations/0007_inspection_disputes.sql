-- Buyer inspection + structured dispute resolution
CREATE TYPE public.inspection_result AS ENUM ('accepted','problem_reported');
CREATE TYPE public.inspection_item_result AS ENUM ('pass','fail','not_applicable');
CREATE TYPE public.dispute_reason AS ENUM ('wrong_product','wrong_specification','damaged','missing_item','wrong_quantity','significantly_different','counterfeit_suspected','other');
CREATE TYPE public.dispute_level AS ENUM ('level_1_objective','level_2_human_review','level_3_expert_manual');
CREATE TYPE public.dispute_status AS ENUM ('open','under_review','awaiting_evidence','expert_review','decision_recorded','appealed','resolved','cancelled');
CREATE TYPE public.dispute_decision AS ENUM ('buyer_favor','seller_favor','partial_refund','return_required','refund_required','no_action','escalate_expert');
CREATE TYPE public.review_assignment_status AS ENUM ('assigned','accepted','completed','reassigned','cancelled');
CREATE TYPE public.return_status AS ENUM ('requested','approved','in_transit','received','inspected','completed','cancelled');
CREATE TYPE public.return_decision AS ENUM ('refund','replacement','no_refund');

CREATE TABLE IF NOT EXISTS public.inspection_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES public.product_categories(id) ON DELETE SET NULL,
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  instructions jsonb NOT NULL DEFAULT '[]',
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.inspection_template_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id uuid NOT NULL REFERENCES public.inspection_templates(id) ON DELETE CASCADE,
  item_key text NOT NULL,
  label text NOT NULL,
  guidance text,
  required boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  UNIQUE(template_id,item_key)
);
CREATE TABLE IF NOT EXISTS public.inspections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id uuid NOT NULL REFERENCES public.transactions(id) ON DELETE CASCADE,
  buyer_id uuid NOT NULL REFERENCES public.profiles(id),
  template_id uuid REFERENCES public.inspection_templates(id),
  status text NOT NULL DEFAULT 'started' CHECK(status IN ('started','submitted','cancelled')),
  result public.inspection_result,
  started_at timestamptz NOT NULL DEFAULT now(),
  submitted_at timestamptz,
  notes text,
  UNIQUE(transaction_id)
);
CREATE TABLE IF NOT EXISTS public.inspection_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  inspection_id uuid NOT NULL REFERENCES public.inspections(id) ON DELETE CASCADE,
  template_item_id uuid REFERENCES public.inspection_template_items(id) ON DELETE SET NULL,
  item_key text NOT NULL,
  result public.inspection_item_result NOT NULL,
  notes text,
  evidence_ids uuid[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(inspection_id,item_key)
);
CREATE TABLE IF NOT EXISTS public.disputes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id uuid NOT NULL REFERENCES public.transactions(id) ON DELETE CASCADE,
  inspection_id uuid REFERENCES public.inspections(id) ON DELETE SET NULL,
  opened_by uuid NOT NULL REFERENCES public.profiles(id),
  description text NOT NULL,
  reason public.dispute_reason NOT NULL,
  level public.dispute_level NOT NULL DEFAULT 'level_1_objective',
  status public.dispute_status NOT NULL DEFAULT 'open',
  decision public.dispute_decision,
  decision_reason text,
  locked_specification_id uuid REFERENCES public.transaction_specifications(id),
  seller_evidence_ids uuid[] NOT NULL DEFAULT '{}',
  buyer_evidence_ids uuid[] NOT NULL DEFAULT '{}',
  delivery_evidence_ids uuid[] NOT NULL DEFAULT '{}',
  inspection_result_id uuid REFERENCES public.inspections(id),
  financial_action text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  decided_at timestamptz,
  resolved_at timestamptz
);
CREATE TABLE IF NOT EXISTS public.dispute_evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dispute_id uuid NOT NULL REFERENCES public.disputes(id) ON DELETE CASCADE,
  evidence_id uuid NOT NULL REFERENCES public.evidence(id) ON DELETE RESTRICT,
  submitted_by uuid NOT NULL REFERENCES public.profiles(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(dispute_id,evidence_id)
);
CREATE TABLE IF NOT EXISTS public.dispute_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dispute_id uuid NOT NULL REFERENCES public.disputes(id) ON DELETE CASCADE,
  actor_id uuid REFERENCES public.profiles(id),
  event_type text NOT NULL,
  from_status public.dispute_status,
  to_status public.dispute_status,
  metadata jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.dispute_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dispute_id uuid NOT NULL REFERENCES public.disputes(id) ON DELETE CASCADE,
  reviewer_id uuid NOT NULL REFERENCES public.profiles(id),
  level public.dispute_level NOT NULL,
  status public.review_assignment_status NOT NULL DEFAULT 'assigned',
  assigned_at timestamptz NOT NULL DEFAULT now(),
  accepted_at timestamptz,
  completed_at timestamptz,
  notes text,
  UNIQUE(dispute_id,reviewer_id,level)
);
CREATE TABLE IF NOT EXISTS public.dispute_decisions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dispute_id uuid NOT NULL REFERENCES public.disputes(id) ON DELETE CASCADE,
  reviewer_id uuid NOT NULL REFERENCES public.profiles(id),
  decision public.dispute_decision NOT NULL,
  reason text NOT NULL,
  evidence_considered uuid[] NOT NULL DEFAULT '{}',
  financial_action text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.dispute_appeals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dispute_id uuid NOT NULL REFERENCES public.disputes(id) ON DELETE CASCADE,
  appealed_by uuid NOT NULL REFERENCES public.profiles(id),
  reason text NOT NULL,
  evidence_ids uuid[] NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'open' CHECK(status IN ('open','under_review','decided','rejected')),
  decision_reason text,
  created_at timestamptz NOT NULL DEFAULT now(),
  decided_at timestamptz
);
CREATE TABLE IF NOT EXISTS public.returns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id uuid NOT NULL REFERENCES public.transactions(id) ON DELETE CASCADE,
  dispute_id uuid REFERENCES public.disputes(id) ON DELETE SET NULL,
  requested_by uuid NOT NULL REFERENCES public.profiles(id),
  status public.return_status NOT NULL DEFAULT 'requested',
  decision public.return_decision,
  reason text,
  tracking_reference text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);
CREATE TABLE IF NOT EXISTS public.return_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  return_id uuid NOT NULL REFERENCES public.returns(id) ON DELETE CASCADE,
  actor_id uuid REFERENCES public.profiles(id),
  event_type text NOT NULL,
  from_status public.return_status,
  to_status public.return_status,
  metadata jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS disputes_tx_idx ON public.disputes(transaction_id,created_at DESC);
CREATE INDEX IF NOT EXISTS disputes_status_idx ON public.disputes(status,level,updated_at DESC);
CREATE INDEX IF NOT EXISTS dispute_events_idx ON public.dispute_events(dispute_id,created_at DESC);
CREATE INDEX IF NOT EXISTS dispute_reviews_reviewer_idx ON public.dispute_reviews(reviewer_id,status);
CREATE INDEX IF NOT EXISTS returns_tx_idx ON public.returns(transaction_id,created_at DESC);

INSERT INTO public.inspection_templates(category_id,slug,name,instructions)
SELECT c.id,c.slug,c.name,'["Record the package before opening.","Compare the received item with the locked specification.","Document every material mismatch or defect.","Submit only after reviewing all checklist items."]'::jsonb
FROM public.product_categories c
WHERE c.slug IN ('phones','laptops','electronics','clothing','household-goods','vehicles','other')
ON CONFLICT(slug) DO NOTHING;

INSERT INTO public.inspection_template_items(template_id,item_key,label,guidance,required,sort_order)
SELECT t.id,x.item_key,x.label,x.guidance,true,x.sort_order
FROM public.inspection_templates t
JOIN (VALUES
 ('phones','product_identity','Model and identity','Confirm brand, model and identifier against the locked specification.',1),
 ('phones','storage','Storage','Confirm advertised storage capacity.',2),
 ('phones','identifier','IMEI/serial','Confirm the relevant identifier matches the locked specification where applicable.',3),
 ('phones','physical_condition','Physical condition','Check screen, body, cameras, buttons and visible damage.',4),
 ('phones','battery','Battery','Check battery health/status where the device exposes it.',5),
 ('phones','camera','Camera','Test front and rear cameras.',6),
 ('phones','speaker','Speaker','Play a test sound and check speaker output.',7),
 ('phones','ports','Ports','Check charging/data ports and included adapters.',8),
 ('phones','accessories','Accessories','Confirm all promised accessories are present.',9),
 ('laptops','product_identity','Model and identity','Confirm brand, model and identifier.',1),
 ('laptops','ram_storage','RAM and storage','Confirm RAM and storage against the locked specification.',2),
 ('laptops','screen','Screen','Check display, pixels, brightness and damage.',3),
 ('laptops','keyboard_trackpad','Keyboard and trackpad','Test keys, trackpad and pointing controls.',4),
 ('laptops','ports','Ports','Check USB, charging, audio and other promised ports.',5),
 ('laptops','battery','Battery','Check battery/charging behavior.',6),
 ('laptops','accessories','Accessories','Confirm charger and promised accessories.',7),
 ('electronics','identity','Product identity','Confirm exact model and identity.',1),
 ('electronics','physical_condition','Physical condition','Check housing, screen and visible defects.',2),
 ('electronics','functionality','Core functionality','Test the principal advertised functions.',3),
 ('electronics','ports','Ports','Test relevant ports and connections.',4),
 ('electronics','accessories','Accessories','Confirm promised accessories.',5),
 ('clothing','item_identity','Item identity','Confirm brand, type, size and stated material.',1),
 ('clothing','size','Size','Confirm received size matches the locked specification.',2),
 ('clothing','material','Material','Check material against the locked specification.',3),
 ('clothing','condition','Condition','Check stains, tears, damage and workmanship.',4),
 ('clothing','quantity','Quantity','Confirm the number of items received.',5),
 ('household-goods','identity','Product identity','Confirm exact product/model where applicable.',1),
 ('household-goods','condition','Physical condition','Check damage, wear and completeness.',2),
 ('household-goods','functionality','Functionality','Test the principal advertised function.',3),
 ('household-goods','accessories','Accessories','Confirm promised accessories.',4),
 ('vehicles','identity','Vehicle identity','Confirm make, model and vehicle identifier.',1),
 ('vehicles','condition','Physical condition','Inspect body, interior and visible defects.',2),
 ('vehicles','mileage','Mileage','Record displayed mileage and compare with the specification.',3),
 ('vehicles','functionality','Functionality','Check agreed core functions.',4),
 ('vehicles','documents','Documents','Confirm promised ownership/service documents without exposing unnecessary personal data.',5),
 ('other','identity','Product identity','Confirm received item matches the locked description.',1),
 ('other','condition','Physical condition','Check visible condition and material defects.',2),
 ('other','functionality','Functionality','Test promised functionality where applicable.',3),
 ('other','quantity','Quantity','Confirm quantity.',4),
 ('other','accessories','Accessories','Confirm promised accessories.',5)
) AS x(slug,item_key,label,guidance,sort_order) ON t.slug=x.slug
ON CONFLICT(template_id,item_key) DO NOTHING;

ALTER TABLE public.inspections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inspection_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.disputes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dispute_evidence ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dispute_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dispute_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dispute_decisions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dispute_appeals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.returns ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.return_events ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.case_access_allowed(uid uuid, tid uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
 SELECT EXISTS(SELECT 1 FROM public.transactions t WHERE t.id=tid AND (t.buyer_id=uid OR t.seller_id=uid OR public.is_staff(uid)));
$$;
REVOKE ALL ON FUNCTION public.case_access_allowed(uuid,uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.case_access_allowed(uuid,uuid) TO authenticated,service_role;

DROP POLICY IF EXISTS inspections_case_access ON public.inspections;
CREATE POLICY inspections_case_access ON public.inspections FOR SELECT USING(public.case_access_allowed(auth.uid(),transaction_id));
DROP POLICY IF EXISTS inspection_results_case_access ON public.inspection_results;
CREATE POLICY inspection_results_case_access ON public.inspection_results FOR SELECT USING(EXISTS(SELECT 1 FROM public.inspections i WHERE i.id=inspection_id AND public.case_access_allowed(auth.uid(),i.transaction_id)));
DROP POLICY IF EXISTS disputes_case_access ON public.disputes;
CREATE POLICY disputes_case_access ON public.disputes FOR SELECT USING(public.case_access_allowed(auth.uid(),transaction_id));
DROP POLICY IF EXISTS dispute_evidence_case_access ON public.dispute_evidence;
CREATE POLICY dispute_evidence_case_access ON public.dispute_evidence FOR SELECT USING(EXISTS(SELECT 1 FROM public.disputes d WHERE d.id=dispute_id AND public.case_access_allowed(auth.uid(),d.transaction_id)));
DROP POLICY IF EXISTS dispute_events_case_access ON public.dispute_events;
CREATE POLICY dispute_events_case_access ON public.dispute_events FOR SELECT USING(EXISTS(SELECT 1 FROM public.disputes d WHERE d.id=dispute_id AND public.case_access_allowed(auth.uid(),d.transaction_id)));
DROP POLICY IF EXISTS dispute_reviews_case_access ON public.dispute_reviews;
CREATE POLICY dispute_reviews_case_access ON public.dispute_reviews FOR SELECT USING(EXISTS(SELECT 1 FROM public.disputes d WHERE d.id=dispute_id AND public.case_access_allowed(auth.uid(),d.transaction_id)));
DROP POLICY IF EXISTS dispute_decisions_case_access ON public.dispute_decisions;
CREATE POLICY dispute_decisions_case_access ON public.dispute_decisions FOR SELECT USING(EXISTS(SELECT 1 FROM public.disputes d WHERE d.id=dispute_id AND public.case_access_allowed(auth.uid(),d.transaction_id)));
DROP POLICY IF EXISTS dispute_appeals_case_access ON public.dispute_appeals;
CREATE POLICY dispute_appeals_case_access ON public.dispute_appeals FOR SELECT USING(EXISTS(SELECT 1 FROM public.disputes d WHERE d.id=dispute_id AND public.case_access_allowed(auth.uid(),d.transaction_id)));
DROP POLICY IF EXISTS returns_case_access ON public.returns;
CREATE POLICY returns_case_access ON public.returns FOR SELECT USING(public.case_access_allowed(auth.uid(),transaction_id));
DROP POLICY IF EXISTS return_events_case_access ON public.return_events;
CREATE POLICY return_events_case_access ON public.return_events FOR SELECT USING(EXISTS(SELECT 1 FROM public.returns r WHERE r.id=return_id AND public.case_access_allowed(auth.uid(),r.transaction_id)));
