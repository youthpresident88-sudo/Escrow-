-- Payment infrastructure invariants. Run against a test Supabase database after migrations.
-- 1. Payment idempotency is unique.
DO $$ BEGIN
  IF NOT EXISTS (select 1 from pg_indexes where indexname='payments_idempotency_unique') THEN RAISE EXCEPTION 'payment idempotency index missing'; END IF;
END $$;
-- 2. Provider webhook events are unique.
DO $$ BEGIN
  IF NOT EXISTS (select 1 from pg_indexes where indexname='payment_events_provider_event_unique') THEN RAISE EXCEPTION 'provider event uniqueness missing'; END IF;
END $$;
-- 3. Sensitive payment records remain participant/staff readable only.
DO $$ BEGIN
  IF NOT EXISTS (select 1 from pg_policies where policyname='payments_participant') THEN RAISE EXCEPTION 'payments RLS policy missing'; END IF;
END $$;
-- 4. Payouts cannot contain non-positive amounts.
DO $$ BEGIN
  IF NOT EXISTS (select 1 from pg_constraint where conname='payouts_amount_minor_check') THEN RAISE EXCEPTION 'payout amount constraint missing'; END IF;
END $$;
