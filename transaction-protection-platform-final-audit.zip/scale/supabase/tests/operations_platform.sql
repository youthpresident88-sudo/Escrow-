-- Run against a test database after migrations.
-- Verify new operational roles are accepted and historical evidence cannot be updated/deleted without the explicit versioning transaction setting.
select exists(select 1 from pg_enum e join pg_type t on t.oid=e.enumtypid where t.typname='app_role' and e.enumlabel='finance') as finance_role_exists;
select exists(select 1 from information_schema.tables where table_schema='public' and table_name='operations_action_log') as action_log_exists;
select exists(select 1 from information_schema.tables where table_schema='public' and table_name='support_cases') as support_cases_exists;
