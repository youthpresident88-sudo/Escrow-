-- Run against a disposable test database after migrations 0001-0008.
-- Verifies schema, category checklists, and transition graph presence.
DO $$ BEGIN
  PERFORM 'inspection_result'::regtype;
  PERFORM 'dispute_reason'::regtype;
  PERFORM 'dispute_level'::regtype;
  PERFORM 'dispute_status'::regtype;
  PERFORM 'refund_request_status'::regtype;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.inspection_templates WHERE slug='phones') THEN RAISE EXCEPTION 'phones inspection template missing'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.inspection_template_items i JOIN public.inspection_templates t ON t.id=i.template_id WHERE t.slug='phones' AND i.item_key='imei') THEN
    -- Identifier evidence is captured separately; checklist must still require identity.
    IF NOT EXISTS (SELECT 1 FROM public.inspection_template_items i JOIN public.inspection_templates t ON t.id=i.template_id WHERE t.slug='phones' AND i.item_key='product_identity') THEN RAISE EXCEPTION 'phone identity checklist missing'; END IF;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT public.valid_transaction_transition('delivered','inspection') THEN RAISE EXCEPTION 'delivery -> inspection missing'; END IF;
  IF NOT public.valid_transaction_transition('inspection','disputed') THEN RAISE EXCEPTION 'inspection -> disputed missing'; END IF;
  IF NOT public.valid_transaction_transition('disputed','refund_pending') THEN RAISE EXCEPTION 'disputed -> refund_pending missing'; END IF;
  IF NOT public.valid_transaction_transition('refund_pending','refunded') THEN RAISE EXCEPTION 'refund_pending -> refunded missing'; END IF;
END $$;
