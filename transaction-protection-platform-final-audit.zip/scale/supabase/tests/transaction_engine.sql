-- Run against a migrated test database with psql or Supabase SQL editor.
-- These are database-level invariants, not mocked application tests.
DO $$
DECLARE
  bad boolean;
BEGIN
  IF NOT public.valid_transaction_transition('created','paid_out') THEN NULL; ELSE RAISE EXCEPTION 'Invalid transition was accepted by graph'; END IF;
  IF NOT public.valid_transaction_transition('created','specification_pending') THEN RAISE EXCEPTION 'Expected seller confirmation transition missing'; END IF;
  IF NOT public.valid_transaction_transition('specification_pending','specification_locked') THEN RAISE EXCEPTION 'Expected buyer confirmation transition missing'; END IF;
  IF NOT public.valid_transaction_transition('specification_locked','awaiting_payment') THEN RAISE EXCEPTION 'Expected payment availability transition missing'; END IF;
  IF NOT public.valid_transaction_transition('payment_pending','payment_secured') THEN RAISE EXCEPTION 'Expected provider confirmation transition missing'; END IF;
  IF public.valid_transaction_transition('payment_secured','specification_pending') THEN RAISE EXCEPTION 'Post-payment amendment must be rejected'; END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname='one_current_specification_per_transaction') THEN
    RAISE EXCEPTION 'Current specification uniqueness index missing';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='transaction_specifications') THEN
    RAISE EXCEPTION 'Specification RLS policy missing';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='transaction_participants') THEN
    RAISE EXCEPTION 'Participant RLS policy missing';
  END IF;
END $$;
