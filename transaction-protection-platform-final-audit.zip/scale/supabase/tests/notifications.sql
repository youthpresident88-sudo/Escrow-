-- Run against a test database after migrations 0001-0010.
select count(*) > 0 as notification_preferences_table_exists from information_schema.tables where table_schema='public' and table_name='notification_preferences';
select count(*) > 0 as notifications_table_exists from information_schema.tables where table_schema='public' and table_name='notifications';
select count(*) > 0 as push_subscriptions_table_exists from information_schema.tables where table_schema='public' and table_name='push_subscriptions';
select count(*) > 0 as provider_events_table_exists from information_schema.tables where table_schema='public' and table_name='notification_provider_events';
select count(*) > 0 as dispatch_table_exists from information_schema.tables where table_schema='public' and table_name='notification_dispatch_events';
-- Logical duplicate protection.
insert into public.notification_preferences(user_id) values('00000000-0000-0000-0000-000000000001') on conflict do nothing;
