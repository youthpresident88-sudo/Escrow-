-- Run after migrations 0001-0006 in a Supabase/PostgreSQL test database.
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM storage.buckets WHERE id='transaction-evidence' AND public=false) THEN
    RAISE EXCEPTION 'transaction-evidence bucket must be private';
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname='evidence_upload_status') THEN RAISE EXCEPTION 'evidence upload status missing'; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname='evidence_event_type') THEN RAISE EXCEPTION 'evidence event type missing'; END IF;
END $$;

-- Locked evidence is never updated by the vault versioning model; a correction references the prior object.
SELECT id, version_no, supersedes_id, is_current
FROM public.evidence
WHERE false;

-- The important production invariant is that a transaction participant cannot directly read evidence belonging to another transaction.
-- Execute this section under authenticated JWTs in integration tests; RLS remains the final database boundary.
