DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname='delivery_one_active_assignment_idx') THEN RAISE EXCEPTION 'Active courier assignment uniqueness missing'; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='inspection_templates' AND policyname='inspection_templates_authenticated_read') THEN RAISE EXCEPTION 'Inspection template RLS missing'; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='audit_log_archive' AND policyname='audit_archive_staff_read') THEN RAISE EXCEPTION 'Audit archive RLS missing'; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname='audit_log_append_only') THEN RAISE EXCEPTION 'Audit append-only trigger missing'; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname='operations_action_log_append_only') THEN RAISE EXCEPTION 'Operations append-only trigger missing'; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE schemaname='public' AND tablename='seller_payout_recipients') THEN RAISE EXCEPTION 'Seller payout recipient table missing'; END IF;
END $$;
