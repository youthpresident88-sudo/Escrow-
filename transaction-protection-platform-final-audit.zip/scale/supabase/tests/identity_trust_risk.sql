-- Requires migrations 0001..0011
begin;
select public.refresh_trust_profile((select id from public.profiles limit 1));
rollback;
