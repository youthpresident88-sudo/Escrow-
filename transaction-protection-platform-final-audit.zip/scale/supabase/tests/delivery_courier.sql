DO $$ BEGIN
  ASSERT to_regclass('public.deliveries') IS NOT NULL, 'deliveries table missing';
  ASSERT to_regclass('public.delivery_events') IS NOT NULL, 'delivery_events table missing';
  ASSERT to_regclass('public.delivery_assignments') IS NOT NULL, 'delivery_assignments table missing';
  ASSERT to_regclass('public.delivery_tracking_points') IS NOT NULL, 'delivery_tracking_points table missing';
  ASSERT EXISTS (SELECT 1 FROM pg_enum e JOIN pg_type t ON t.oid=e.enumtypid WHERE t.typname='app_role' AND e.enumlabel='courier'), 'courier role missing';
  ASSERT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname='delivery_events_transaction_time_idx'), 'delivery event transaction index missing';
END $$;
