'use client';
import { useEffect, useMemo, useState } from 'react';
import * as tus from 'tus-js-client';

const API=process.env.NEXT_PUBLIC_API_URL??'http://localhost:4000';
const TYPES=[
 ['seller_condition','Seller condition video'],['seller_condition_photo','Condition photographs'],['serial_imei','Serial / IMEI evidence'],['packaging','Packaging evidence'],['dispatch','Dispatch evidence'],
 ['pickup','Courier pickup evidence'],['delivery','Delivery evidence'],['delivery_confirmation','Delivery confirmation'],['unboxing','Package-before-opening / unboxing'],['inspection','Inspection photographs'],['inspection_video','Inspection video'],['problem','Problem evidence'],
 ['return_packaging','Return packaging'],['return_dispatch','Return dispatch'],['return_receipt','Return receipt'],['return_inspection','Seller return inspection'],['dispute_supporting','Dispute supporting evidence'],['dispute_additional','Additional dispute evidence'],['expert','Expert evidence']
] as const;

async function hash(file:File){if(file.size>100*1024*1024)return '';const buffer=await file.arrayBuffer();const digest=await crypto.subtle.digest('SHA-256',buffer);return Array.from(new Uint8Array(digest)).map(x=>x.toString(16).padStart(2,'0')).join('');}
async function mediaMeta(file:File){
  if(file.type.startsWith('image/')){const url=URL.createObjectURL(file);try{const i=new Image();i.src=url;await i.decode();return {dimensions:{width:i.naturalWidth,height:i.naturalHeight}}}finally{URL.revokeObjectURL(url)}}
  if(file.type.startsWith('video/')){const url=URL.createObjectURL(file);try{const v=document.createElement('video');v.preload='metadata';v.src=url;await new Promise<void>((resolve,reject)=>{v.onloadedmetadata=()=>resolve();v.onerror=()=>reject(new Error('Could not read video metadata'))});return {dimensions:{width:v.videoWidth,height:v.videoHeight},durationMs:Math.round(v.duration*1000)}}finally{URL.revokeObjectURL(url)}}
  return {};
}

export default function EvidenceVault(){
 const [token,setToken]=useState(''); const [transactionId,setTransactionId]=useState(''); const [type,setType]=useState<(typeof TYPES)[number][0]>('seller_condition'); const [file,setFile]=useState<File|null>(null); const [hashValue,setHashValue]=useState(''); const [progress,setProgress]=useState(0); const [status,setStatus]=useState(''); const [timeline,setTimeline]=useState<any[]>([]); const [evidence,setEvidence]=useState<any[]>([]); const [instructions,setInstructions]=useState<string[]>([]); const [busy,setBusy]=useState(false);
 const selectedLabel=useMemo(()=>TYPES.find(x=>x[0]===type)?.[1]??type,[type]);
 async function api(path:string,options:any={}){const r=await fetch(`${API}${path}`,{...options,headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json',...(options.headers??{})}});const data=await r.json().catch(()=>({}));if(!r.ok)throw new Error(data.error??`Request failed (${r.status})`);return data;}
 async function load(){if(!token||!transactionId)return;setBusy(true);try{const d=await api(`/v1/transactions/${transactionId}/evidence`);setEvidence(d.evidence);setTimeline(d.timeline)}catch(e:any){setStatus(e.message)}finally{setBusy(false)}}
 useEffect(()=>{if(token&&transactionId)load()},[token,transactionId]);
 useEffect(()=>{if(!token)return;api(`/v1/evidence/types/${type}/instructions`).then(d=>setInstructions(d.instructions)).catch(()=>setInstructions([]))},[type,token]);
 async function prepare(){if(!file||!transactionId)throw new Error('Transaction and file are required');setStatus(file.size<=100*1024*1024?'Calculating client SHA-256…':'Preparing large-file upload (server will calculate SHA-256)…');const h=await hash(file);setHashValue(h);const meta=await mediaMeta(file);return {h,meta}}
 async function upload(){if(!file)return;setBusy(true);setProgress(0);try{const {h,meta}=await prepare();setStatus('Creating secure upload…');const init=await api(`/v1/transactions/${transactionId}/evidence/uploads`,{method:'POST',headers:{'Idempotency-Key':crypto.randomUUID()},body:JSON.stringify({type,filename:file.name,mimeType:file.type||'application/octet-stream',byteSize:file.size,sha256:h,dimensions:meta.dimensions,durationMs:meta.durationMs,deviceInfo:{userAgent:navigator.userAgent,platform:navigator.platform},captureMetadata:{clientLastModified:file.lastModified}})});
   setStatus('Uploading original file with resumable storage…'); await new Promise<void>((resolve,reject)=>{const upload=new tus.Upload(file,{endpoint:init.resumable.endpoint,chunkSize:init.resumable.chunkSize,retryDelays:init.resumable.retryDelays,headers:{'x-signature':init.resumable.signature},metadata:{bucketName:init.resumable.bucket,objectName:init.resumable.objectName,contentType:file.type||'application/octet-stream',cacheControl:'3600'},onError:error=>reject(error),onProgress:(bytes,total)=>setProgress(Math.round(bytes/total*100)),onSuccess:()=>resolve()});upload.findPreviousUploads().then(previous=>{if(previous.length)upload.resumeFromPreviousUpload(previous[0]);upload.start()}).catch(reject)});
   setStatus('Upload complete. Server worker is verifying the original object and SHA-256…');await api(`/v1/evidence/uploads/${init.uploadId}/complete`,{method:'POST',body:JSON.stringify({sha256:h})});setFile(null);setProgress(100);for(let i=0;i<30;i++){await new Promise(r=>setTimeout(r,1000));const d=await api(`/v1/transactions/${transactionId}/evidence`);setEvidence(d.evidence);setTimeline(d.timeline);if(d.evidence.some((e:any)=>e.sha256===h)){setStatus('Evidence verified and permanently recorded in the timeline.');break;}if(i===29)setStatus('Upload accepted; verification is still processing. Refresh later to see the verified evidence.');}
 }catch(e:any){setStatus(e.message);setProgress(0)}finally{setBusy(false)}}
 return <main className="page"><section className="card"><h1>Evidence Vault</h1><p className="muted">Original files are stored privately. The server independently hashes the stored object before marking evidence verified.</p>
  <label>Access token<input value={token} onChange={e=>setToken(e.target.value)} placeholder="Bearer token" /></label>
  <label>Transaction ID<input value={transactionId} onChange={e=>setTransactionId(e.target.value)} placeholder="Transaction UUID" /></label>
  <div className="grid2"><label>Evidence type<select value={type} onChange={e=>setType(e.target.value as any)}>{TYPES.map(([v,l])=><option key={v} value={v}>{l}</option>)}</select></label><label>Capture<input type="file" accept="image/*,video/*,.pdf" capture="environment" onChange={e=>setFile(e.target.files?.[0]??null)} /></label></div>
  <div className="notice"><strong>Guided capture</strong><ol>{instructions.map((x,i)=><li key={i}>{x}</li>)}</ol></div>
  {file&&<p className="muted">{file.name} · {(file.size/1024/1024).toFixed(2)} MB {hashValue?`· client SHA-256 ${hashValue.slice(0,16)}…`:'· server-side SHA-256 verification'}</p>}
  <button disabled={!token||!transactionId||!file||busy} onClick={upload}>{busy?`Uploading ${progress}%…`:'Capture / upload evidence'}</button>{progress>0&&<progress value={progress} max="100" />}{status&&<p className="status">{status}</p>}
 </section>
 <section className="card"><div className="row"><h2>Evidence timeline</h2><button onClick={load} disabled={!token||!transactionId||busy}>Refresh</button></div>{timeline.length===0?<p className="muted">No evidence events yet.</p>:<div className="timeline">{timeline.map((e:any)=><article key={e.id}><b>{e.event_type.replaceAll('_',' ')}</b><span>{new Date(e.occurred_at).toLocaleString()}</span><small>{e.metadata?JSON.stringify(e.metadata):''}</small></article>)}</div>}
  <h2>Recorded evidence</h2>{evidence.map((e:any)=><article className="evidence" key={e.id}><div><b>{e.type.replaceAll('_',' ')}</b><span>v{e.version_no} · {e.mime_type} · {(Number(e.byte_size)/1024/1024).toFixed(2)} MB</span><span>SHA-256: {e.sha256}</span><span>Captured: {new Date(e.captured_at).toLocaleString()}</span></div><a href={`${API}/v1/evidence/${e.id}`} onClick={async ev=>{ev.preventDefault();try{const d=await api(`/v1/evidence/${e.id}`);window.open(d.signedUrl,'_blank','noopener,noreferrer')}catch(x:any){setStatus(x.message)}}}>Open securely</a></article>)}
 </section></main>
}
