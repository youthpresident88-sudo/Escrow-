'use client';
import { FormEvent, useEffect, useState } from 'react';

const API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000';

type Category = { slug:string; name:string; fields:{fieldKey:string;label:string;fieldType:string;required:boolean}[] };
type Tx = { id:string; reference:string; status:string; specification?:any };

export default function TransactionsPage(){
  const [token,setToken]=useState('');
  const [categories,setCategories]=useState<Category[]>([]);
  const [buyerId,setBuyerId]=useState('');
  const [category,setCategory]=useState('phones');
  const [productName,setProductName]=useState('');
  const [description,setDescription]=useState('');
  const [price,setPrice]=useState('');
  const [quantity,setQuantity]=useState('1');
  const [condition,setCondition]=useState('');
  const [items,setItems]=useState<Record<string,string>>({});
  const [tx,setTx]=useState<Tx|null>(null);
  const [transactionId,setTransactionId]=useState('');
  const [message,setMessage]=useState('');
  const [busy,setBusy]=useState(false);

  useEffect(()=>{ fetch(`${API}/v1/transaction-categories`).then(r=>r.json()).then(setCategories).catch(()=>setMessage('Could not load product categories.')); },[]);
  const selected=categories.find(c=>c.slug===category);
  const request=async(path:string,options:RequestInit={})=>{const r=await fetch(`${API}${path}`,{...options,headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`,...(options.headers||{})}});const body=await r.json();if(!r.ok)throw new Error(body.error||'Request failed');return body;};
  async function create(e:FormEvent){e.preventDefault();setBusy(true);setMessage('');try{const body=await request('/v1/transactions',{method:'POST',headers:{'Idempotency-Key':crypto.randomUUID()},body:JSON.stringify({buyerUserId:buyerId,categorySlug:category,productName,description,priceMinor:Math.round(Number(price)*100),currency:'GHS',quantity:Number(quantity),condition,deliveryTerms:{method:'Seller and buyer agree in transaction chat'},returnTerms:{windowHours:48},specificationItems:Object.entries(items).filter(([,v])=>String(v).trim()).map(([fieldKey,value])=>({fieldKey,label:selected?.fields.find(f=>f.fieldKey===fieldKey)?.label??fieldKey,value}))})});setTx(body);setMessage('Transaction created. The buyer must review and confirm the locked agreement.');}catch(e:any){setMessage(e.message)}finally{setBusy(false)}}
  async function loadTransaction(){if(!transactionId)return;setBusy(true);setMessage('');try{setTx(await request(`/v1/transactions/${transactionId}`));}catch(e:any){setMessage(e.message)}finally{setBusy(false)}}
  async function confirm(){if(!tx)return;setBusy(true);setMessage('');try{const body=await request(`/v1/transactions/${tx.id}/specification/confirm`,{method:'POST',body:'{}'});setTx(body.transaction);setMessage(body.locked?'Agreement locked. Payment is now available.':'Seller confirmation recorded. Waiting for buyer confirmation.');}catch(e:any){setMessage(e.message)}finally{setBusy(false)}}
  return <main className="page"><div className="shell"><header><div className="eyebrow">EVIDENCE-FIRST TRANSACTION</div><h1>Create the agreement before money moves.</h1><p>Seller creates the terms. Both parties confirm. Only then does protected payment become available.</p></header>
    <section className="panel"><h2>Transaction workspace</h2><label>Access token<input value={token} onChange={e=>setToken(e.target.value)} placeholder="Paste an authenticated access token" /></label><label>Open existing transaction<input value={transactionId} onChange={e=>setTransactionId(e.target.value)} placeholder="Transaction UUID" /><button type="button" disabled={busy||!token||!transactionId} onClick={loadTransaction}>Open transaction</button></label><label>Buyer user ID<input value={buyerId} onChange={e=>setBuyerId(e.target.value)} placeholder="Buyer UUID" /></label>
      <form onSubmit={create}><div className="grid"><label>Category<select value={category} onChange={e=>{setCategory(e.target.value);setItems({})}}>{categories.map(c=><option key={c.slug} value={c.slug}>{c.name}</option>)}</select></label><label>Product name<input required value={productName} onChange={e=>setProductName(e.target.value)}/></label><label>Price (GHS)<input required type="number" min="0.01" step="0.01" value={price} onChange={e=>setPrice(e.target.value)}/></label><label>Quantity<input required type="number" min="1" value={quantity} onChange={e=>setQuantity(e.target.value)}/></label></div><label>Description<textarea required value={description} onChange={e=>setDescription(e.target.value)}/></label><label>Condition<textarea required value={condition} onChange={e=>setCondition(e.target.value)} placeholder="Describe exact condition, defects, accessories and exclusions."/></label>{selected?.fields.map(f=><label key={f.fieldKey}>{f.label}{f.required?' *':''}<input required={f.required} value={items[f.fieldKey]??''} onChange={e=>setItems(x=>({...x,[f.fieldKey]:e.target.value}))}/></label>)}<button disabled={busy||!token||!buyerId}>{busy?'Working…':'Create transaction agreement'}</button></form></section>
    {tx&&<section className="panel"><div className="status"><span>{tx.reference}</span><b>{tx.status}</b></div><h2>Agreement review</h2><p>Every confirmation is recorded against this specification version. Locked specifications cannot be silently edited.</p><button disabled={busy} onClick={confirm}>{busy?'Confirming…':'Confirm specification'}</button></section>}
    {message&&<div className="notice">{message}</div>}
  </div></main>
}
