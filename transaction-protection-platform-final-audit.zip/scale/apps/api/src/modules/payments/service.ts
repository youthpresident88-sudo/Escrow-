import crypto from 'node:crypto';
import{pool}from'../../db.js';import{PaystackAdapter}from'./paystack.js';import type{PaymentChannel,PaymentProvider}from'./provider.js';
const providers:Record<string,()=>PaymentProvider>={paystack:()=>new PaystackAdapter()};
export function paymentProvider(name='paystack'){const p=providers[name]?.();if(!p)throw new Error(`Unsupported payment provider: ${name}`);return p}
import {assertAccountActionAllowed} from '../identity-risk/service.js';
import {env} from '../../config.js';
export async function initializePayment(transactionId:string,actorId:string,key:string,channel:PaymentChannel='card',mobileMoney?:{phone:string;provider:'mtn'|'vod'|'atl'}){
 await assertAccountActionAllowed(actorId,'initialize_payment');
 const c=await pool.connect();
 let intent:any;
 let released=false;
 try{
  await c.query('begin');
  const idem=await c.query(`select response from public.idempotency_keys where scope='payment_init' and key=$1 and actor_id=$2 for update`,[key,actorId]);
  if(idem.rows[0]){await c.query('commit');c.release();released=true;return idem.rows[0].response;}
  const r=await c.query(`select t.*,u.email from public.transactions t join auth.users u on u.id=t.buyer_id where t.id=$1 and t.buyer_id=$2 for update`,[transactionId,actorId]);
  const t=r.rows[0];if(!t)throw new Error('Transaction not found');
  if(t.status!=='awaiting_payment')throw new Error(`Cannot initialize payment from ${t.status}`);
  const reference=`${t.reference}-${crypto.randomUUID()}`;
  const response={provider:'paystack',reference,channel,status:'initializing',authorizationUrl:null,displayText:null};
  const payment=(await c.query(`insert into public.payments(transaction_id,provider,provider_reference,amount_minor,currency,status,channel,idempotency_key,provider_status,metadata,expires_at) values($1,'paystack',$2,$3,'GHS','pending',$4,$5,'initializing',$6,now()+interval '15 minutes') returning *`,[transactionId,reference,t.amount_minor,channel,{transactionId,initializationKey:key}])).rows[0];
  await c.query(`insert into public.payment_events(payment_id,transaction_id,provider,kind,provider_status,amount_minor,currency,payload,idempotency_key) values($1,$2,'paystack','initialized','initializing',$3,'GHS',$4,$5)`,[payment.id,transactionId,t.amount_minor,{reference,channel},`payment-initialized:${reference}`]);
  await c.query(`select public.transition_transaction($1,$2,'payment_pending',$3,$4)`,[transactionId,actorId,`payment-init:${reference}`,{paymentReference:reference,channel}]);
  await c.query(`insert into public.idempotency_keys(scope,key,actor_id,response) values('payment_init',$1,$2,$3)`,[key,actorId,response]);
  await c.query('commit');
  c.release();released=true;
  intent={transactionId,actorId,email:t.email,amountMinor:Number(t.amount_minor),reference,channel,mobileMoney,paymentId:payment.id,response};
 }catch(e){await c.query('rollback').catch(()=>{});if(!released)c.release();throw e}
 try{
  const data=await paymentProvider('paystack').initialize({email:intent.email,amountMinor:intent.amountMinor,reference:intent.reference,callbackUrl:`${env.APP_BASE_URL}/transactions/${transactionId}/payment`,currency:'GHS',channel:intent.channel,metadata:{transaction_id:transactionId,payment_id:intent.paymentId},mobileMoney:intent.mobileMoney});
  const response={provider:'paystack',reference:intent.reference,channel:intent.channel,status:data?.status??'pending',authorizationUrl:data?.authorization_url??null,displayText:data?.display_text??null};
  await pool.query(`update public.payments set provider_status=$2,metadata=metadata || $3,updated_at=now() where id=$1`,[intent.paymentId,data?.status??'pending',data??{}]);
  await pool.query(`update public.idempotency_keys set response=$2 where scope='payment_init' and key=$1 and actor_id=$3`,[key,response,actorId]);
  return response;
 }catch(e){
  await pool.query(`update public.payments set status='failed',provider_status='initialization_failed',failure_reason=$2,updated_at=now() where id=$1 and status='pending'`,[intent.paymentId,String((e as any)?.message??e)]).catch(()=>{});
  await pool.query(`update public.idempotency_keys set response=$2 where scope='payment_init' and key=$1 and actor_id=$3`,[key,{provider:'paystack',reference:intent.reference,channel:intent.channel,status:'failed',authorizationUrl:null,displayText:null},actorId]).catch(()=>{});
  throw e;
 }
}

export async function reconcilePayments(limit=100){const c=await pool.connect();let runId:string|undefined;try{const rr=await c.query(`insert into public.payment_reconciliation_runs(provider) values('paystack') returning id`);runId=rr.rows[0].id;const rows=await c.query(`select * from public.payments where provider='paystack' and status in ('pending','initiated') and (updated_at<now()-interval '2 minutes' or expires_at<now()) order by updated_at asc limit $1`,[limit]);let corrected=0,failed=0;for(const p of rows.rows){try{const data=await paymentProvider('paystack').verify(p.provider_reference);const status=String(data.status??'').toLowerCase();if(status==='success'&&(Number(data.amount)!==Number(p.amount_minor)||String(data.currency??'').toUpperCase()!==String(p.currency).toUpperCase()))throw new Error('Provider payment amount or currency mismatch');const mapped=status==='success'?'successful':status==='failed'?'failed':status==='abandoned'?'cancelled':status==='reversed'?'reversed':p.expires_at&&new Date(p.expires_at)<new Date()?'expired':'pending';await c.query('begin');await c.query(`update public.payments set status=$2,provider_status=$3,amount_paid_minor=case when $2='successful' then $4 else amount_paid_minor end,updated_at=now(),settled_at=case when $2='successful' then now() else settled_at end where id=$1`,[p.id,mapped,status,Number(data.amount??p.amount_minor)]);await c.query(`insert into public.payment_events(payment_id,transaction_id,provider,kind,provider_status,amount_minor,currency,payload,idempotency_key) values($1,$2,'paystack',$3,$4,$5,$6,$7,$8) on conflict do nothing`,[p.id,p.transaction_id,mapped==='successful'?'successful':mapped==='failed'?'failed':mapped==='cancelled'?'cancelled':mapped==='expired'?'expired':'reconciled',status,data.amount??p.amount_minor,p.currency,data,`reconcile:${p.id}:${status}:${data.id??data.reference??''}`]);if(mapped==='successful')await c.query(`select public.transition_transaction($1,NULL,'payment_secured',$2,$3)`,[p.transaction_id,`payment-reconcile:${p.id}`,{provider:'paystack',source:'reconciliation'}]);await c.query('commit');corrected++}catch(e){await c.query('rollback');failed++}}await c.query(`update public.payment_reconciliation_runs set completed_at=now(),scanned_count=$2,corrected_count=$3,failed_count=$4,status='completed' where id=$1`,[runId,rows.rowCount,corrected,failed]);return{runId,scanned:rows.rowCount,corrected,failed}}catch(e){if(runId)await c.query(`update public.payment_reconciliation_runs set completed_at=now(),status='failed',error=$2 where id=$1`,[runId,String(e)]);throw e}finally{c.release()}}
async function maybeMarkPaidOut(transactionId:string){
 const q=await pool.query(`select t.status,p.amount_minor,p.amount_refunded_minor,coalesce((select sum(amount_minor) from public.payouts po where po.transaction_id=t.id and po.status='successful'),0) paid_out from public.transactions t join public.payments p on p.transaction_id=t.id and p.status in ('successful','refunded') where t.id=$1 order by p.created_at desc limit 1`,[transactionId]);
 const r=q.rows[0];if(!r)return;const net=Number(r.amount_minor)-Number(r.amount_refunded_minor??0);if(['accepted','resolved'].includes(r.status)&&Number(r.paid_out)>=net)await pool.query(`select public.transition_transaction($1,NULL,'paid_out',$2,$3)`,[transactionId,`payout-complete:${transactionId}`,{paidOutMinor:Number(r.paid_out),netAmountMinor:net}]);
}
export async function createPayoutRecipient(sellerId:string,input:{accountName:string;accountNumber:string;bankCode:string;currency?:string}){
 await assertAccountActionAllowed(sellerId,'create_payout_recipient');
 if(!/^[A-Za-z0-9 .,'-]{2,120}$/.test(input.accountName.trim()))throw Object.assign(new Error('Invalid account name'),{statusCode:422});
 if(!/^\d{6,30}$/.test(input.accountNumber))throw Object.assign(new Error('Invalid account number'),{statusCode:422});
 if(!/^[A-Za-z0-9_-]{2,40}$/.test(input.bankCode))throw Object.assign(new Error('Invalid bank code'),{statusCode:422});
 const currency=(input.currency??'GHS').toUpperCase();if(currency!=='GHS')throw Object.assign(new Error('Only GHS payout accounts are supported'),{statusCode:422});
 const data=await paymentProvider('paystack').createTransferRecipient({name:input.accountName.trim(),accountNumber:input.accountNumber,bankCode:input.bankCode,currency});
 const code=String(data?.recipient_code??'');if(!code)throw Object.assign(new Error('Payment provider did not return a recipient reference'),{statusCode:502});
 return (await pool.query(`insert into public.seller_payout_recipients(seller_id,provider,provider_recipient_code,account_name,account_last4,bank_code,currency,metadata) values($1,'paystack',$2,$3,$4,$5,$6,$7) on conflict(provider,provider_recipient_code) do update set status='active',account_name=excluded.account_name,account_last4=excluded.account_last4,bank_code=excluded.bank_code,updated_at=now() returning id,seller_id,provider,provider_recipient_code,account_name,account_last4,bank_code,currency,status,created_at,updated_at`,[sellerId,code,input.accountName.trim(),input.accountNumber.slice(-4),input.bankCode,currency,{providerResponse:{name:data?.name??null}}])).rows[0];
}
export async function listPayoutRecipients(sellerId:string){return (await pool.query(`select id,provider,provider_recipient_code,account_name,account_last4,bank_code,currency,status,created_at,updated_at from public.seller_payout_recipients where seller_id=$1 order by created_at desc`,[sellerId])).rows;}

export async function createPayout(transactionId:string,actorId:string,key:string,amountMinor:number,recipientId:string,reason:string){
 await assertAccountActionAllowed(actorId,'create_payout');
 const existing=await pool.query(`select po.* from public.payouts po join public.transactions t on t.id=po.transaction_id where po.idempotency_key=$1 and t.seller_id=$2`,[key,actorId]);
 if(existing.rows[0]&&existing.rows[0].status==='successful')return existing.rows[0];
 const c=await pool.connect();let payout:any;try{await c.query('begin');
  const t=(await c.query(`select * from public.transactions where id=$1 and seller_id=$2 for update`,[transactionId,actorId])).rows[0];if(!t)throw new Error('Transaction not found or not seller');
  if(!['accepted','resolved'].includes(t.status))throw new Error(`Cannot payout from ${t.status}`);
  const p=(await c.query(`select * from public.payments where transaction_id=$1 and status='successful' order by created_at desc limit 1`,[transactionId])).rows[0];if(!p)throw new Error('No successful payment');
  if(amountMinor<=0||amountMinor>Number(p.amount_minor)-Number(p.amount_refunded_minor))throw new Error('Invalid payout amount');
  const recipient=(await c.query(`select * from public.seller_payout_recipients where id=$1 and seller_id=$2 and provider='paystack' and status='active' for update`,[recipientId,actorId])).rows[0];if(!recipient)throw Object.assign(new Error('Verified payout recipient not found'),{statusCode:422});
  if(existing.rows[0]){payout=existing.rows[0];if(payout.recipient_reference!==recipient.provider_recipient_code)throw Object.assign(new Error('Existing payout recipient does not match the verified seller recipient'),{statusCode:409});}else payout=(await c.query(`insert into public.payouts(transaction_id,payment_id,provider,amount_minor,currency,status,recipient_reference,idempotency_key,metadata) values($1,$2,'paystack',$3,$4,'initiated',$5,$6,$7) returning *`,[transactionId,p.id,amountMinor,p.currency,recipient.provider_recipient_code,key,{reason,recipientId:recipient.id}])).rows[0];
  await c.query('commit');
 }catch(e){await c.query('rollback');throw e}finally{c.release()}
 if(payout.status==='successful')return payout;
 const reference=payout.provider_reference??`payout-${payout.id}`;
 try{const data=await paymentProvider('paystack').transfer({amountMinor:Number(payout.amount_minor),recipient:payout.recipient_reference,reason,reference,currency:payout.currency});const updated=await pool.query(`update public.payouts set provider_reference=$2,status=$3,metadata=metadata || $4,updated_at=now() where id=$1 returning *`,[payout.id,data.reference??reference,data.status==='success'?'successful':'pending',data]);if(data.status==='success')await maybeMarkPaidOut(transactionId);return updated.rows[0]}catch(e){await pool.query(`update public.payouts set status='failed',failure_reason=$2,updated_at=now() where id=$1`,[payout.id,String((e as any)?.message??e)]);throw e}
}
