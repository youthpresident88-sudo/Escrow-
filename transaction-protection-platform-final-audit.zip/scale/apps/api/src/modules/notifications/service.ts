import { createHash, createHmac } from 'node:crypto';
import { pool } from '../../db.js';

export const NOTIFICATION_EVENTS = [
'account.created','email.verification','phone.verification','security.login','transaction.created','specification.awaiting_confirmation','specification.locked','payment.initiated','payment.confirmed','payment.failed','seller.evidence.required','seller.evidence.completed','dispatch.required','dispatched','delivery.confirmed','inspection.required','inspection.completed','dispute.opened','evidence.requested','dispute.updated','dispute.resolved','return.required','refund.initiated','refund.completed','payout.initiated','payout.completed'
] as const;
export type NotificationEvent = typeof NOTIFICATION_EVENTS[number];
export type Channel = 'sms'|'email'|'push'|'in_app';

const templates: Record<string,{subject:string;body:string}> = {
 'account.created':{subject:'Your account is ready',body:'Your account has been created successfully.'},
 'email.verification':{subject:'Verify your email',body:'Please verify your email address to secure your account.'},
 'phone.verification':{subject:'Verify your phone',body:'Please complete phone verification.'},
 'security.login':{subject:'New sign-in to your account',body:'A new sign-in was recorded on your account.'},
 'transaction.created':{subject:'Transaction created',body:'A protected transaction has been created.'},
 'specification.awaiting_confirmation':{subject:'Specification requires confirmation',body:'Review and confirm the transaction specification.'},
 'specification.locked':{subject:'Specification locked',body:'The transaction specification is now locked.'},
 'payment.initiated':{subject:'Payment initiated',body:'Payment authorization has started.'},
 'payment.confirmed':{subject:'Payment confirmed',body:'Your protected payment has been confirmed.'},
 'payment.failed':{subject:'Payment failed',body:'Your payment could not be completed. You may retry.'},
 'seller.evidence.required':{subject:'Seller evidence required',body:'Please complete the required seller evidence.'},
 'seller.evidence.completed':{subject:'Seller evidence completed',body:'Seller evidence has been recorded.'},
 'dispatch.required':{subject:'Dispatch required',body:'The transaction is ready for dispatch.'},
 'dispatched':{subject:'Item dispatched',body:'The item has been marked as dispatched.'},
 'delivery.confirmed':{subject:'Delivery confirmed',body:'Delivery has been confirmed.'},
 'inspection.required':{subject:'Inspection required',body:'Your inspection window is now open. Record the package and inspect the item.'},
 'inspection.completed':{subject:'Inspection completed',body:'The buyer inspection has been recorded.'},
 'dispute.opened':{subject:'Dispute opened',body:'A dispute has been opened for a protected transaction.'},
 'evidence.requested':{subject:'Additional evidence requested',body:'Additional evidence is required for review.'},
 'dispute.updated':{subject:'Dispute updated',body:'There is an update to your dispute.'},
 'dispute.resolved':{subject:'Dispute resolved',body:'Your dispute has a recorded resolution.'},
 'return.required':{subject:'Return required',body:'A return action is required.'},
 'refund.initiated':{subject:'Refund initiated',body:'Your refund has been initiated.'},
 'refund.completed':{subject:'Refund completed',body:'Your refund has been completed by the payment provider.'},
 'payout.initiated':{subject:'Payout initiated',body:'A seller payout has been initiated.'},
 'payout.completed':{subject:'Payout completed',body:'The seller payout has been completed.'}
};
function render(eventKey:string,payload:any){const t=templates[eventKey]??{subject:'Transaction protection update',body:'There is an update to your protected transaction.'};const json=JSON.stringify(payload??{});const suffix=json.length>500?json.slice(0,500):json;return{...t,body:`${t.body}${suffix==='{}'?'':`\n\nReference: ${suffix}`}`};}
function channelsFor(eventKey:string):Channel[]{if(eventKey.startsWith('security.'))return ['email','sms','in_app'];return ['in_app','email','push','sms'];}
export async function enqueueNotification(userId:string,eventKey:string,payload:any,idempotencyBase:string,channels:Channel[]=channelsFor(eventKey)){
 const r=await pool.query(`select email,phone from public.profiles where id=$1 and deleted_at is null`,[userId]); if(!r.rows[0]) return [];
 const pref=(await pool.query(`select * from public.notification_preferences where user_id=$1`,[userId])).rows[0] ?? {email:'enabled',sms:'enabled',push:'enabled',in_app:'enabled',security_email:true,security_sms:true};
 const created:string[]=[]; for(const channel of channels){ if(pref[channel]==='disabled')continue; if(eventKey.startsWith('security.')&&channel==='email'&&!pref.security_email)continue; if(eventKey.startsWith('security.')&&channel==='sms'&&!pref.security_sms)continue; const key=`${idempotencyBase}:${channel}`;
  const ins=await pool.query(`insert into public.notifications(user_id,event_key,channel,template,payload,idempotency_key) values($1,$2,$3,$4,$5,$6) on conflict(idempotency_key) do nothing returning id`,[userId,eventKey,channel,eventKey,payload,key]);
  await pool.query(`insert into public.notification_outbox(user_id,channel,template,payload,idempotency_key,event_key,notification_id) values($1,$2,$3,$4,$5,$6,$7) on conflict(idempotency_key) do nothing`,[userId,channel,eventKey,payload,key,eventKey,ins.rows[0]?.id ?? null]); if(ins.rows[0])created.push(ins.rows[0].id);
 }
 return created;
}
export async function listNotifications(userId:string,limit=50){return (await pool.query(`select * from public.notifications where user_id=$1 order by created_at desc limit $2`,[userId,Math.min(Math.max(limit,1),100)])).rows;}
export async function markNotificationRead(userId:string,id:string){const r=await pool.query(`update public.notifications set payload=jsonb_set(payload,'{read}','true'::jsonb,true),updated_at=now() where id=$1 and user_id=$2 returning *`,[id,userId]);if(!r.rows[0])throw Object.assign(new Error('Notification not found'),{statusCode:404});return r.rows[0];}
export async function savePushSubscription(userId:string,input:any,userAgent?:string){const r=await pool.query(`insert into public.push_subscriptions(user_id,endpoint,p256dh,auth,user_agent) values($1,$2,$3,$4,$5) on conflict(endpoint) do update set user_id=excluded.user_id,p256dh=excluded.p256dh,auth=excluded.auth,user_agent=excluded.user_agent,last_used_at=now() returning *`,[userId,input.endpoint,input.keys.p256dh,input.keys.auth,userAgent??null]);return r.rows[0];}
export async function updateProviderEvent(provider:string,eventId:string,eventType:string,payload:any,notificationId?:string){return pool.query(`insert into public.notification_provider_events(provider,provider_event_id,event_type,notification_id,payload) values($1,$2,$3,$4,$5) on conflict(provider,provider_event_id) do nothing`,[provider,eventId,eventType,notificationId??null,payload]);}
export async function notificationTemplate(eventKey:string,payload:any){return render(eventKey,payload);}
export function verifyTwilioWebhook(signature:string,url:string,params:Record<string,string>,authToken:string){const data=url+Object.keys(params).sort().map(k=>k+params[k]).join('');const expected=createHmac('sha1',authToken).update(data).digest('base64');return signature===expected;}
