import crypto from 'node:crypto';
import { createClient } from '@supabase/supabase-js';
import { pool, tx } from '../../db.js';
import { env } from '../../config.js';

const BUCKET = 'transaction-evidence';
const MAX_BYTES = Number(process.env.EVIDENCE_MAX_BYTES ?? 1024 * 1024 * 1024);
const SIGNED_UPLOAD_SECONDS = 2 * 60 * 60;
const SIGNED_READ_SECONDS = 5 * 60;

const storage = env.SUPABASE_URL && env.SUPABASE_SERVICE_ROLE_KEY
  ? createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false, autoRefreshToken: false } })
  : null;

export const EVIDENCE_TYPES = [
  'seller_condition','seller_condition_photo','serial_imei','packaging','dispatch',
  'pickup','delivery','delivery_confirmation','unboxing','inspection','inspection_video','problem',
  'return_packaging','return_dispatch','return_receipt','return_inspection',
  'dispute_supporting','dispute_additional','expert','agreement','identity'
] as const;
export type EvidenceType = typeof EVIDENCE_TYPES[number];

const SELLER_TYPES = new Set<EvidenceType>(['seller_condition','seller_condition_photo','serial_imei','packaging','dispatch']);
const BUYER_TYPES = new Set<EvidenceType>(['unboxing','inspection','inspection_video','problem']);
const COURIER_TYPES = new Set<EvidenceType>(['pickup','delivery','delivery_confirmation']);
const RETURN_TYPES = new Set<EvidenceType>(['return_packaging','return_dispatch','return_receipt','return_inspection']);
const DISPUTE_TYPES = new Set<EvidenceType>(['dispute_supporting','dispute_additional','expert']);

function assertStorage() { if (!storage) throw Object.assign(new Error('Evidence storage is not configured'), { statusCode: 503 }); return storage; }
function bad(message:string,statusCode=400):never { throw Object.assign(new Error(message),{statusCode}); }
function uuidPath(id:string, filename:string) { const safe = filename.replace(/[^a-zA-Z0-9._-]/g,'_').slice(-120) || 'evidence.bin'; return `transactions/${id}/${crypto.randomUUID()}-${safe}`; }
function allowedForRole(type:EvidenceType, role:string, staff:boolean) {
  if (staff) return true;
  if (SELLER_TYPES.has(type)) return role === 'seller';
  if (BUYER_TYPES.has(type)) return role === 'buyer';
  if (COURIER_TYPES.has(type)) return role === 'courier' || role === 'support' || role === 'risk_analyst' || role === 'admin' || role === 'super_admin' || role === 'operations' || role === 'dispute_reviewer' || role === 'compliance';
  if (RETURN_TYPES.has(type)) return role === 'buyer' || role === 'seller' || role === 'support' || role === 'risk_analyst' || role === 'admin' || role === 'super_admin' || role === 'operations' || role === 'dispute_reviewer' || role === 'compliance';
  if (DISPUTE_TYPES.has(type)) return role === 'buyer' || role === 'seller' || role === 'support' || role === 'risk_analyst' || role === 'admin' || role === 'super_admin' || role === 'operations' || role === 'dispute_reviewer' || role === 'compliance';
  return role === 'buyer' || role === 'seller' || role === 'courier' || role === 'support' || role === 'risk_analyst' || role === 'admin' || role === 'super_admin' || role === 'operations' || role === 'dispute_reviewer' || role === 'compliance';
}

async function participant(transactionId:string, userId:string) {
  const r = await pool.query(`
    select t.id,t.status,t.buyer_id,t.seller_id,
      case when t.buyer_id=$2 then 'buyer' when t.seller_id=$2 then 'seller' when exists(select 1 from public.deliveries d where d.transaction_id=t.id and d.courier_user_id=$2) then 'courier' else null end as participant_role,
      exists(select 1 from public.user_roles ur where ur.user_id=$2 and ur.role in ('support','risk_analyst','admin','super_admin','operations','dispute_reviewer','finance','compliance')) as staff
    from public.transactions t where t.id=$1`, [transactionId,userId]);
  if (!r.rows[0]) bad('Transaction not found',404);
  const row=r.rows[0];
  if (!row.participant_role && !row.staff) bad('Evidence access denied',403);
  return row;
}

export async function listEvidence(transactionId:string,userId:string) {
  await participant(transactionId,userId);
  const r=await pool.query(`
    select e.id,e.transaction_id,e.submitted_by,e.type,e.storage_path,e.sha256,e.mime_type,e.byte_size,
      e.captured_at,e.created_at,e.version_no,e.supersedes_id,e.is_current,e.original_filename,e.file_extension,
      e.dimensions,e.duration_ms,e.device_info,e.capture_metadata,e.upload_completed_at,e.verified_at,
      e.privacy_classification,
      p.display_name as uploader_name,
      coalesce((select jsonb_agg(jsonb_build_object('id',ee.id,'eventType',ee.event_type,'actorId',ee.actor_id,'metadata',ee.metadata,'occurredAt',ee.occurred_at) order by ee.occurred_at asc) from public.evidence_events ee where ee.evidence_id=e.id),'[]'::jsonb) as events
    from public.evidence e join public.profiles p on p.id=e.submitted_by
    where e.transaction_id=$1 order by e.created_at asc`,[transactionId]);
  const timeline=await pool.query(`select id,evidence_id,upload_id,actor_id,event_type,metadata,occurred_at from public.evidence_events where transaction_id=$1 order by occurred_at asc`,[transactionId]);
  return {evidence:r.rows,timeline:timeline.rows};
}

export async function createUpload(input:{transactionId:string;userId:string;type:EvidenceType;filename:string;mimeType:string;byteSize:number;sha256?:string;capturedAt?:string;dimensions?:unknown;durationMs?:number;deviceInfo?:unknown;captureMetadata?:unknown;supersedesEvidenceId?:string;}) {
  const s=assertStorage();
  if(!EVIDENCE_TYPES.includes(input.type)) bad('Unsupported evidence type');
  if(!Number.isSafeInteger(input.byteSize)||input.byteSize<=0||input.byteSize>MAX_BYTES) bad(`Evidence size must be between 1 byte and ${MAX_BYTES} bytes`);
  if(input.sha256 && !/^[a-fA-F0-9]{64}$/.test(input.sha256)) bad('Invalid SHA-256');
  const mime=String(input.mimeType||'').toLowerCase().split(';')[0].trim();
  const allowedMime=/^(image\/(jpeg|png|webp|heic|heif)|video\/(mp4|quicktime|webm)|application\/pdf)$/.test(mime);
  if(!allowedMime) bad('Unsupported evidence MIME type',422);
  if(input.filename.length<1||input.filename.length>255) bad('Evidence filename must be 1-255 characters',422);
  if(input.durationMs!==undefined&&(!Number.isFinite(Number(input.durationMs))||Number(input.durationMs)<0||Number(input.durationMs)>24*60*60*1000)) bad('Invalid media duration',422);
  const part=await participant(input.transactionId,input.userId);
  if(!allowedForRole(input.type,part.participant_role,part.staff)) bad('You are not authorized to submit this evidence type',403);
  if(input.supersedesEvidenceId){
    const old=await pool.query(`select id,transaction_id,submitted_by,is_current from public.evidence where id=$1 and transaction_id=$2`,[input.supersedesEvidenceId,input.transactionId]);
    if(!old.rows[0]||!old.rows[0].is_current) bad('Evidence version cannot be superseded',409);
  }
  const path=uuidPath(input.transactionId,input.filename);
  const signed=await s.storage.from(BUCKET).createSignedUploadUrl(path,{upsert:false});
  if(signed.error||!signed.data) throw Object.assign(new Error(signed.error?.message??'Could not create upload URL'),{statusCode:503});
  const expiresAt=new Date(Date.now()+SIGNED_UPLOAD_SECONDS*1000).toISOString();
  const result=await tx(async c=>{
    const u=await c.query(`insert into public.evidence_uploads(transaction_id,uploader_id,type,storage_path,original_filename,mime_type,expected_byte_size,expected_sha256,upload_token_expires_at,metadata) values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) returning *`,[
      input.transactionId,input.userId,input.type,path,input.filename,mime,input.byteSize,input.sha256??null,expiresAt,{dimensions:input.dimensions??null,durationMs:input.durationMs??null,deviceInfo:input.deviceInfo??{},captureMetadata:input.captureMetadata??{},supersedesEvidenceId:input.supersedesEvidenceId??null,capturedAt:input.capturedAt??null}
    ]);
    await c.query(`insert into public.evidence_events(transaction_id,upload_id,actor_id,event_type,metadata) values($1,$2,$3,'upload_created',$4)`,[input.transactionId,u.rows[0].id,input.userId,{type:input.type,expectedByteSize:input.byteSize}]);
    return u.rows[0];
  });
  const supabaseUrl=env.SUPABASE_URL??''; const host=supabaseUrl.match(/^https?:\/\/([^/.]+)\.supabase\.co/i)?.[1]; const resumableEndpoint=host?`https://${host}.storage.supabase.co/storage/v1/upload/resumable`:`${supabaseUrl.replace(/\/$/,'')}/storage/v1/upload/resumable`; return {uploadId:result.id,path,signedUrl:signed.data.signedUrl,uploadToken:(signed.data as any).token??null,expiresAt,requiredHeaders:{'content-type':input.mimeType,'cache-control':'3600'},resumable:{protocol:'tus',endpoint:resumableEndpoint,bucket:BUCKET,objectName:path,signature:(signed.data as any).token??null,chunkSize:6*1024*1024,retryDelays:[0,3000,5000,10000,20000]},maxBytes:MAX_BYTES};
}

async function hashSignedObject(path:string) {
  const s=assertStorage();
  const signed=await s.storage.from(BUCKET).createSignedUrl(path,SIGNED_READ_SECONDS);
  if(signed.error||!signed.data) throw new Error(signed.error?.message??'Could not create verification URL');
  const response=await fetch(signed.data.signedUrl);
  if(!response.ok||!response.body) throw new Error(`Storage verification download failed (${response.status})`);
  const hash=crypto.createHash('sha256'); let bytes=0;
  const reader=response.body.getReader();
  while(true){const {done,value}=await reader.read();if(done)break;if(value){bytes+=value.byteLength;hash.update(value);}}
  return {sha256:hash.digest('hex'),byteSize:bytes};
}

export async function completeUpload(uploadId:string,userId:string,clientSha256?:string) {
  const q=await pool.query(`select eu.*,t.status from public.evidence_uploads eu join public.transactions t on t.id=eu.transaction_id where eu.id=$1 and eu.uploader_id=$2`,[uploadId,userId]);
  if(!q.rows[0]) bad('Upload not found',404);
  const u=q.rows[0];
  await participant(u.transaction_id,userId);
  if(u.status==='verified' && u.evidence_id) return getEvidence(u.evidence_id,userId);
  if(u.status==='expired') bad('Upload URL expired',410);
  if(new Date(u.upload_token_expires_at)<new Date()) { await pool.query(`update public.evidence_uploads set status='expired',error_message='Upload URL expired' where id=$1`,[uploadId]); bad('Upload URL expired',410); }
  await pool.query(`update public.evidence_uploads set status='uploaded',updated_at=now(),metadata=metadata || $2 where id=$1 and status in ('pending','uploaded')`,[uploadId,{clientSha256:clientSha256??null}]);
  await pool.query(`insert into public.evidence_events(transaction_id,upload_id,actor_id,event_type,metadata) values($1,$2,$3,'upload_completed',$4)`,[u.transaction_id,uploadId,userId,{clientSha256:clientSha256??null}]);
  await pool.query(`insert into public.jobs(queue,job_type,payload,idempotency_key) values('evidence','evidence.hash',$1,$2) on conflict(idempotency_key) do nothing`,[{uploadId,clientSha256:clientSha256??null},`evidence-hash:${uploadId}`]);
  return {uploadId,status:'processing',message:'Upload received. Server-side integrity verification is processing.'};
}

export async function verifyStoredUploadForWorker(uploadId:string){
  const q=await pool.query(`select * from public.evidence_uploads where id=$1`,[uploadId]); if(!q.rows[0]) throw new Error('Upload not found'); const u=q.rows[0];
  if(u.status==='verified') return;
  const {sha256,byteSize}=await hashSignedObject(u.storage_path);
  if(byteSize!==Number(u.expected_byte_size)) throw new Error('Uploaded file size does not match declared size');
  const clientSha=String((u.metadata??{}).clientSha256??''); if(u.expected_sha256 && sha256.toLowerCase()!==u.expected_sha256.toLowerCase()) throw new Error('SHA-256 integrity check failed');
  if(clientSha && sha256.toLowerCase()!==clientSha.toLowerCase()) throw new Error('Client SHA-256 does not match server verification');
  const metadata=u.metadata??{}; const capturedAt=metadata.capturedAt?new Date(metadata.capturedAt):new Date();
  await tx(async c=>{
    let version=1; let supersedesId=null;
    if(metadata.supersedesEvidenceId){ await c.query(`set local app.evidence_versioning='true'`); const old=await c.query(`select id,version_no from public.evidence where id=$1 and transaction_id=$2 and is_current=true for update`,[metadata.supersedesEvidenceId,u.transaction_id]); if(!old.rows[0]) throw new Error('Superseded evidence is no longer current'); version=Number(old.rows[0].version_no)+1; supersedesId=old.rows[0].id; await c.query(`update public.evidence set is_current=false where id=$1`,[supersedesId]); }
    const ins=await c.query(`insert into public.evidence(transaction_id,submitted_by,type,storage_path,sha256,mime_type,byte_size,captured_at,metadata,version_no,supersedes_id,is_current,original_filename,file_extension,dimensions,duration_ms,device_info,capture_metadata,upload_completed_at,verified_at) values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,true,$12,$13,$14,$15,$16,$17,now(),now()) returning *`,[u.transaction_id,u.uploader_id,u.type,u.storage_path,sha256,u.mime_type,byteSize,capturedAt,metadata,version,supersedesId,u.original_filename,(u.original_filename??'').split('.').pop()?.toLowerCase()??null,metadata.dimensions??null,metadata.durationMs??null,metadata.deviceInfo??{},metadata.captureMetadata??{}]);
    await c.query(`update public.evidence_uploads set status='verified',evidence_id=$2,error_message=null,updated_at=now() where id=$1`,[uploadId,ins.rows[0].id]);
    await c.query(`insert into public.evidence_events(transaction_id,evidence_id,upload_id,actor_id,event_type,metadata) values($1,$2,$3,$4,'hash_calculated',$5),($1,$2,$3,$4,'verified',$6)`,[u.transaction_id,ins.rows[0].id,uploadId,u.uploader_id,{sha256,byteSize},{sha256,byteSize,verifiedAgainst:'storage-object'}]);
    if(supersedesId) await c.query(`insert into public.evidence_events(transaction_id,evidence_id,upload_id,actor_id,event_type,metadata) values($1,$2,$3,$4,'version_created',$5),($1,$6,$3,$4,'superseded',$5)`,[u.transaction_id,ins.rows[0].id,uploadId,u.uploader_id,{supersedesId},supersedesId]);
  });
}

export async function getEvidence(id:string,userId:string){
  const q=await pool.query(`select e.*,t.buyer_id,t.seller_id from public.evidence e join public.transactions t on t.id=e.transaction_id where e.id=$1`,[id]);
  if(!q.rows[0]) bad('Evidence not found',404); const e=q.rows[0]; await participant(e.transaction_id,userId);
  const url=assertStorage(); const signed=await url.storage.from(BUCKET).createSignedUrl(e.storage_path,SIGNED_READ_SECONDS);
  if(signed.error||!signed.data) bad('Evidence is temporarily unavailable',503);
  await pool.query(`insert into public.evidence_events(transaction_id,evidence_id,actor_id,event_type,metadata) values($1,$2,$3,'accessed',$4)`,[e.transaction_id,id,userId,{expiresIn:SIGNED_READ_SECONDS}]);
  const versions=await pool.query(`with recursive chain as (select id,supersedes_id from public.evidence where id=$2 and transaction_id=$1 union select e.id,e.supersedes_id from public.evidence e join chain c on e.id=c.supersedes_id or e.supersedes_id=c.id where e.transaction_id=$1) select e.id,e.version_no,e.supersedes_id,e.is_current,e.sha256,e.byte_size,e.mime_type,e.captured_at,e.created_at,e.submitted_by,e.verified_at from public.evidence e join chain c on c.id=e.id order by e.version_no asc`,[e.transaction_id,id]);
  return {...e,signedUrl:signed.data.signedUrl,signedUrlExpiresIn:SIGNED_READ_SECONDS,versions:versions.rows};
}

export async function getEvidenceInstructions(type:EvidenceType) {
  const instructions:Record<string,string[]>={
    seller_condition:['Record continuously where possible. Show the whole item first.','Show front, back, sides, model/identifier and all visible defects.','Do not edit or apply filters. Keep the item and recording context visible.'],
    seller_condition_photo:['Use good lighting. Capture the full item and close-ups of every defect.','Photograph identifiers only where lawful and necessary; avoid unrelated personal information.'],
    serial_imei:['Show the device identifier screen and the physical identifier label where available.','Never expose unrelated accounts, passwords, OTPs or personal messages.'],
    packaging:['Show the item entering its packaging and the sealed package from multiple sides.'],
    dispatch:['Show the sealed parcel, shipping label and handoff context. Avoid exposing unnecessary recipient data.'],
    unboxing:['Before opening, record all sides of the unopened package.','Open continuously where possible and keep the contents in frame.'],
    inspection:['Compare the received item against the locked transaction specification.','Capture every material mismatch or defect clearly.'],
    inspection_video:['Follow the guided checklist and demonstrate relevant functions.','Keep demonstrations continuous where practical.'],
    problem:['Show the problem clearly and demonstrate the relevant condition/function without editing.']
  };
  return instructions[type]??['Capture clear, relevant evidence showing the condition or event.','Do not edit the original file before upload.','Avoid unrelated personal or sensitive information.'];
}
