import { createHash, randomBytes } from 'node:crypto';
import { pool, tx } from '../../db.js';
import {
  AmendSpecificationSchema,
  ConfirmSpecificationSchema,
  CreateTransactionSchema,
  type TransactionStatus
} from '@platform/contracts';

const ref = () => `TX-${Date.now().toString(36).toUpperCase()}-${randomBytes(4).toString('hex').toUpperCase()}`;

function httpError(message: string, statusCode = 400) {
  const e = new Error(message) as Error & { statusCode?: number };
  e.statusCode = statusCode;
  return e;
}

async function categoryAndFields(c: any, slug: string) {
  const r = await c.query(`
    SELECT c.id, c.slug, c.name,
           COALESCE(jsonb_agg(jsonb_build_object(
             'fieldKey', f.field_key, 'label', f.label, 'fieldType', f.field_type,
             'required', f.required, 'options', f.options, 'validation', f.validation
           ) ORDER BY f.sort_order) FILTER (WHERE f.id IS NOT NULL), '[]'::jsonb) AS fields
    FROM public.product_categories c
    LEFT JOIN public.category_spec_fields f ON f.category_id=c.id
    WHERE c.slug=$1 AND c.is_active=true
    GROUP BY c.id`, [slug]);
  if (!r.rows[0]) throw httpError('Unknown or inactive product category', 400);
  return r.rows[0];
}

function validateSpecificationFields(fields: any[], items: Array<{ fieldKey: string; label: string; value: unknown }>) {
  const definitions = new Map(fields.map(f => [f.fieldKey, f]));
  const supplied = new Map(items.map(i => [i.fieldKey, i]));
  for (const [key, def] of definitions) {
    if (def.required && !supplied.has(key)) throw httpError(`Missing required specification field: ${key}`);
  }
  for (const item of items) {
    if (!definitions.has(item.fieldKey)) throw httpError(`Unsupported specification field: ${item.fieldKey}`);
  }
}

async function insertSpecification(c: any, transactionId: string, version: number, actorId: string, input: any, category: any) {
  validateSpecificationFields(category.fields, input.specificationItems);
  const spec = await c.query(`
    INSERT INTO public.transaction_specifications(
      transaction_id,version,category_id,product_name,description,price_minor,currency,quantity,
      condition,delivery_terms,return_terms,status,created_by
    ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'draft'::public.specification_status,$12)
    RETURNING *`, [
      transactionId, version, category.id, input.productName, input.description, input.priceMinor,
      input.currency, input.quantity, input.condition, input.deliveryTerms, input.returnTerms, actorId
    ]);
  const specification = spec.rows[0];
  for (const item of input.specificationItems) {
    await c.query(`INSERT INTO public.specification_items(specification_id,field_key,label,value) VALUES($1,$2,$3,$4)`, [
      specification.id, item.fieldKey, item.label, item.value
    ]);
  }
  return specification;
}

import {assertAccountActionAllowed} from '../identity-risk/service.js';
export async function createTransaction(input: unknown, sellerId: string, key: string) {
  await assertAccountActionAllowed(sellerId,'create_transaction');
  const p = CreateTransactionSchema.parse(input);
  if (p.buyerUserId === sellerId) throw httpError('Buyer and seller must be different');
  return tx(async c => {
    const old = await c.query(`SELECT response FROM public.idempotency_keys WHERE scope='create_transaction' AND key=$1 AND actor_id=$2`, [key, sellerId]);
    if (old.rows[0]) return old.rows[0].response;

    const buyer = await c.query(`SELECT id FROM public.profiles WHERE id=$1 AND deleted_at IS NULL`, [p.buyerUserId]);
    if (!buyer.rows[0]) throw httpError('Buyer account not found', 404);
    const category = await categoryAndFields(c, p.categorySlug);
    const reference = ref();

    const r = await c.query(`
      INSERT INTO public.transactions(reference,buyer_id,seller_id,title,description,amount_minor,currency,terms,status,category_id)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,'created',$9)
      RETURNING *`, [reference, p.buyerUserId, sellerId, p.productName, p.description, p.priceMinor, p.currency,
      { condition: p.condition, deliveryTerms: p.deliveryTerms, returnTerms: p.returnTerms, quantity: p.quantity }, category.id]);
    const transaction = r.rows[0];

    const specification = await insertSpecification(c, transaction.id, 1, sellerId, p, category);
    await c.query(`UPDATE public.transactions SET current_specification_id=$1 WHERE id=$2`, [specification.id, transaction.id]);
    await c.query(`INSERT INTO public.transaction_events(transaction_id,actor_id,event_type,to_status,metadata,idempotency_key) VALUES($1,$2,'transaction.created','created',$3,$4)`, [transaction.id, sellerId, { reference, specificationVersion: 1 }, key]);
    await c.query(`INSERT INTO public.idempotency_keys(scope,key,actor_id,response) VALUES('create_transaction',$1,$2,$3)`, [key, sellerId, { ...transaction, current_specification_id: specification.id }]);
    return { ...transaction, current_specification_id: specification.id, specification };
  });
}

async function getParticipant(c: any, transactionId: string, userId: string) {
  const r = await c.query(`SELECT role FROM public.transaction_participants WHERE transaction_id=$1 AND user_id=$2 AND left_at IS NULL`, [transactionId, userId]);
  return r.rows[0]?.role as string | undefined;
}

export async function confirmSpecification(transactionId: string, userId: string, input: unknown, ip?: string, userAgent?: string) {
  const p = ConfirmSpecificationSchema.parse(input ?? {});
  return tx(async c => {
    const tResult = await c.query(`SELECT * FROM public.transactions WHERE id=$1 FOR UPDATE`, [transactionId]);
    const t = tResult.rows[0];
    if (!t) throw httpError('Transaction not found', 404);
    const role = await getParticipant(c, transactionId, userId);
    if (role !== 'buyer' && role !== 'seller') throw httpError('Only buyer or seller can confirm the specification', 403);
    const specResult = await c.query(`SELECT * FROM public.transaction_specifications WHERE id=$1 FOR UPDATE`, [t.current_specification_id]);
    const spec = specResult.rows[0];
    if (!spec) throw httpError('Current specification not found', 409);
    if (spec.status !== 'draft') throw httpError('This specification is already locked or superseded', 409);
    if ((role === 'seller' && t.status !== 'created') || (role === 'buyer' && t.status !== 'specification_pending')) {
      throw httpError(`Cannot confirm specification while transaction is ${t.status}`, 409);
    }

    const hash = p.confirmationHash ?? createHash('sha256').update(JSON.stringify({
      transactionId, specificationId: spec.id, version: spec.version, productName: spec.product_name,
      description: spec.description, priceMinor: spec.price_minor, currency: spec.currency,
      quantity: spec.quantity, condition: spec.condition, deliveryTerms: spec.delivery_terms, returnTerms: spec.return_terms
    })).digest('hex');

    await c.query(`
      INSERT INTO public.specification_confirmations(specification_id,user_id,participant_role,status,confirmation_hash,ip,user_agent)
      VALUES($1,$2,$3,'confirmed',$4,$5,$6)
      ON CONFLICT(specification_id,user_id,participant_role) DO UPDATE SET status='confirmed',confirmed_at=now(),confirmation_hash=EXCLUDED.confirmation_hash,ip=EXCLUDED.ip,user_agent=EXCLUDED.user_agent`,
      [spec.id, userId, role, hash, ip ?? null, userAgent ?? null]);

    if (role === 'seller') {
      const updated = await c.query(`SELECT * FROM public.transition_transaction($1,$2,'specification_pending',$3,$4)`, [transactionId, userId, `spec-confirm:${spec.id}:seller`, { specificationId: spec.id, confirmationId: hash }]);
      return { transaction: updated.rows[0], specification: spec, confirmedRole: role, locked: false };
    }

    const both = await c.query(`SELECT count(*)::int AS count FROM public.specification_confirmations WHERE specification_id=$1 AND status='confirmed' AND participant_role IN ('buyer','seller')`, [spec.id]);
    if (both.rows[0].count !== 2) throw httpError('Seller confirmation is still required', 409);

    await c.query(`UPDATE public.transaction_specifications SET status='locked',locked_at=now() WHERE id=$1`, [spec.id]);
    const locked = await c.query(`SELECT * FROM public.transition_transaction($1,$2,'specification_locked',$3,$4)`, [transactionId, userId, `spec-lock:${spec.id}`, { specificationId: spec.id, version: spec.version }]);
    const available = await c.query(`SELECT * FROM public.transition_transaction($1,$2,'awaiting_payment',$3,$4)`, [transactionId, userId, `payment-available:${spec.id}`, { specificationId: spec.id }]);
    return { transaction: available.rows[0], specification: { ...spec, status: 'locked', locked_at: new Date().toISOString() }, confirmedRole: role, locked: true, previousTransition: locked.rows[0] };
  });
}

export async function amendSpecification(transactionId: string, userId: string, input: unknown, key: string) {
  const p = AmendSpecificationSchema.parse(input);
  return tx(async c => {
    const idem = await c.query(`SELECT response FROM public.idempotency_keys WHERE scope='amend_specification' AND key=$1 AND actor_id=$2`, [key, userId]);
    if (idem.rows[0]) return idem.rows[0].response;
    const tResult = await c.query(`SELECT * FROM public.transactions WHERE id=$1 FOR UPDATE`, [transactionId]);
    const t = tResult.rows[0];
    if (!t) throw httpError('Transaction not found', 404);
    const role = await getParticipant(c, transactionId, userId);
    if (role !== 'buyer' && role !== 'seller') throw httpError('Only buyer or seller can amend specifications', 403);
    if (!['specification_locked','awaiting_payment'].includes(t.status)) throw httpError('Amendments are unavailable after payment processing begins', 409);

    const currentResult = await c.query(`SELECT * FROM public.transaction_specifications WHERE id=$1 FOR UPDATE`, [t.current_specification_id]);
    const current = currentResult.rows[0];
    const category = await categoryAndFields(c, p.categorySlug);
    const nextVersionResult = await c.query(`SELECT COALESCE(max(version),0)+1 AS version FROM public.transaction_specifications WHERE transaction_id=$1`, [transactionId]);
    const version = Number(nextVersionResult.rows[0].version);
    await c.query(`UPDATE public.transaction_specifications SET status='superseded' WHERE id=$1 AND status='locked'`, [current.id]);
    const specification = await insertSpecification(c, transactionId, version, userId, p, category);
    await c.query(`UPDATE public.transactions SET current_specification_id=$1,category_id=$2,title=$3,description=$4,amount_minor=$5,currency=$6,terms=$7,updated_at=now() WHERE id=$8`, [specification.id, category.id, p.productName, p.description, p.priceMinor, p.currency, {condition:p.condition,deliveryTerms:p.deliveryTerms,returnTerms:p.returnTerms,quantity:p.quantity}, transactionId]);

    if (t.status !== 'specification_pending') {
      await c.query(`SELECT public.transition_transaction($1,$2,'specification_pending',$3,$4)`, [transactionId, userId, `amend:${specification.id}:pending`, { reason: p.reason, supersededSpecificationId: current.id, newSpecificationId: specification.id }]);
    }
    const response = { transactionId, specification, previousSpecificationId: current.id, reason: p.reason };
    await c.query(`INSERT INTO public.idempotency_keys(scope,key,actor_id,response) VALUES('amend_specification',$1,$2,$3)`, [key, userId, response]);
    return response;
  });
}

export async function getTransaction(id: string, userId: string) {
  const r = await pool.query(`
    SELECT t.*, jsonb_build_object('id',s.id,'version',s.version,'categoryId',s.category_id,'productName',s.product_name,
      'description',s.description,'priceMinor',s.price_minor,'currency',s.currency,'quantity',s.quantity,'condition',s.condition,
      'deliveryTerms',s.delivery_terms,'returnTerms',s.return_terms,'status',s.status,'lockedAt',s.locked_at,
      'items',COALESCE((SELECT jsonb_agg(jsonb_build_object('fieldKey',i.field_key,'label',i.label,'value',i.value) ORDER BY i.field_key) FROM public.specification_items i WHERE i.specification_id=s.id),'[]'::jsonb),
      'confirmations',COALESCE((SELECT jsonb_agg(jsonb_build_object('userId',c.user_id,'role',c.participant_role,'status',c.status,'confirmedAt',c.confirmed_at)) FROM public.specification_confirmations c WHERE c.specification_id=s.id),'[]'::jsonb)
    ) AS specification
    FROM public.transactions t
    LEFT JOIN public.transaction_specifications s ON s.id=t.current_specification_id
    WHERE t.id=$1 AND (t.buyer_id=$2 OR t.seller_id=$2 OR public.is_staff($2))`, [id, userId]);
  return r.rows[0] ?? null;
}

export async function listCategories() {
  const r = await pool.query(`SELECT c.id,c.slug,c.name,c.description,jsonb_agg(jsonb_build_object('fieldKey',f.field_key,'label',f.label,'fieldType',f.field_type,'required',f.required,'options',f.options,'validation',f.validation) ORDER BY f.sort_order) FILTER(WHERE f.id IS NOT NULL) AS fields FROM public.product_categories c LEFT JOIN public.category_spec_fields f ON f.category_id=c.id WHERE c.is_active=true GROUP BY c.id ORDER BY c.name`);
  return r.rows;
}
