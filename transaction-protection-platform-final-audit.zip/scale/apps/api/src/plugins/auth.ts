import type { FastifyRequest } from 'fastify';
import { authorize } from '../modules/auth/service.js';
export async function requireUser(req:FastifyRequest,role?:string){const h=req.headers.authorization;if(!h?.startsWith('Bearer '))throw Object.assign(new Error('Authentication required'),{statusCode:401});return authorize(h.slice(7),role);}
