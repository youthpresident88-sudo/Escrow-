import pg from 'pg';
import { env } from './config.js';

const common={max:env.DB_POOL_MAX,idleTimeoutMillis:env.DB_IDLE_TIMEOUT_MS,connectionTimeoutMillis:env.DB_CONNECTION_TIMEOUT_MS,statement_timeout:env.DB_STATEMENT_TIMEOUT_MS,application_name:'transaction-protection-api'};
export const pool = new pg.Pool({connectionString:env.DATABASE_URL,...common});
export const readPool = new pg.Pool({connectionString:env.DATABASE_READ_URL??env.DATABASE_URL,...common,application_name:'transaction-protection-api-read'});
export async function tx<T>(fn:(client:pg.PoolClient)=>Promise<T>):Promise<T>{const c=await pool.connect();try{await c.query('BEGIN');const r=await fn(c);await c.query('COMMIT');return r}catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}
export async function withRead<T>(fn:(client:pg.PoolClient)=>Promise<T>):Promise<T>{const c=await readPool.connect();try{return await fn(c)}finally{c.release()}}
export async function closePools(){await Promise.all([pool.end(),readPool.end()]);}
