import 'dotenv/config';

function required(name:string){const v=process.env[name];if(!v)throw new Error(`${name} is required`);return v;}
function num(name:string, fallback:number){const v=Number(process.env[name]??fallback);if(!Number.isFinite(v)||v<=0)throw new Error(`${name} must be a positive number`);return v;}

if((process.env.NODE_ENV??'development')==='production'){
  const requiredProduction=['APP_BASE_URL','API_BASE_URL','SUPABASE_URL','SUPABASE_ANON_KEY','SUPABASE_SERVICE_ROLE_KEY','PAYSTACK_SECRET_KEY','PAYSTACK_WEBHOOK_SECRET','RESEND_API_KEY','EMAIL_FROM','TWILIO_ACCOUNT_SID','TWILIO_AUTH_TOKEN','TWILIO_FROM_NUMBER','SMILE_IDENTITY_API_KEY','SMILE_IDENTITY_PARTNER_ID','SMILE_IDENTITY_WEBHOOK_SECRET'];
  const missing=requiredProduction.filter(k=>!process.env[k]);
  if(missing.length)throw new Error(`Production configuration missing: ${missing.join(', ')}`);
  if(/^https?:\/\/(localhost|127\.0\.0\.1)/i.test(process.env.APP_BASE_URL) || /^https?:\/\/(localhost|127\.0\.0\.1)/i.test(process.env.API_BASE_URL)) throw new Error('Production URLs must not point to localhost');
}
export const env={
 NODE_ENV:process.env.NODE_ENV??'development',
 PORT:Number(process.env.PORT??4000),
 DATABASE_URL:required('DATABASE_URL'),
 DATABASE_READ_URL:process.env.DATABASE_READ_URL,
 DB_POOL_MAX:num('DB_POOL_MAX',20),
 DB_IDLE_TIMEOUT_MS:num('DB_IDLE_TIMEOUT_MS',30000),
 DB_STATEMENT_TIMEOUT_MS:num('DB_STATEMENT_TIMEOUT_MS',15000),
 DB_CONNECTION_TIMEOUT_MS:num('DB_CONNECTION_TIMEOUT_MS',5000),
 REDIS_URL:process.env.REDIS_URL,
 APP_BASE_URL:process.env.APP_BASE_URL??'http://localhost:3000',
 API_BASE_URL:process.env.API_BASE_URL??'http://localhost:4000',
 SUPABASE_URL:process.env.SUPABASE_URL,
 SUPABASE_ANON_KEY:process.env.SUPABASE_ANON_KEY,
 SUPABASE_SERVICE_ROLE_KEY:process.env.SUPABASE_SERVICE_ROLE_KEY,
 PAYSTACK_SECRET_KEY:process.env.PAYSTACK_SECRET_KEY,
 PAYSTACK_WEBHOOK_SECRET:process.env.PAYSTACK_WEBHOOK_SECRET,
 PAYSTACK_BASE_URL:process.env.PAYSTACK_BASE_URL??'https://api.paystack.co',
 RESEND_API_KEY:process.env.RESEND_API_KEY,
 RESEND_WEBHOOK_SECRET:process.env.RESEND_WEBHOOK_SECRET,
 EMAIL_FROM:process.env.EMAIL_FROM,
 TWILIO_ACCOUNT_SID:process.env.TWILIO_ACCOUNT_SID,
 TWILIO_AUTH_TOKEN:process.env.TWILIO_AUTH_TOKEN,
 TWILIO_FROM_NUMBER:process.env.TWILIO_FROM_NUMBER,
 VAPID_PUBLIC_KEY:process.env.VAPID_PUBLIC_KEY,
 VAPID_PRIVATE_KEY:process.env.VAPID_PRIVATE_KEY,
 VAPID_SUBJECT:process.env.VAPID_SUBJECT,
 SMILE_IDENTITY_BASE_URL:process.env.SMILE_IDENTITY_BASE_URL,
 SMILE_IDENTITY_API_KEY:process.env.SMILE_IDENTITY_API_KEY,
 SMILE_IDENTITY_PARTNER_ID:process.env.SMILE_IDENTITY_PARTNER_ID,
 SMILE_IDENTITY_WEBHOOK_SECRET:process.env.SMILE_IDENTITY_WEBHOOK_SECRET,
 EVIDENCE_MAX_BYTES:num('EVIDENCE_MAX_BYTES',1024*1024*1024),
 REQUEST_TIMEOUT_MS:num('REQUEST_TIMEOUT_MS',15000),
 SHUTDOWN_TIMEOUT_MS:num('SHUTDOWN_TIMEOUT_MS',10000),
};
