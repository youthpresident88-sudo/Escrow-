import { z } from 'zod';

export const TransactionStatus = z.enum([
  'created','specification_pending','specification_locked','awaiting_payment','payment_pending','payment_secured',
  'awaiting_dispatch','dispatched','delivered','inspection','accepted','disputed','resolved','return_pending',
  'refunded','paid_out','cancelled','expired','funded','seller_preparing','inspection_pending'
]);
export type TransactionStatus = z.infer<typeof TransactionStatus>;

const JsonObject = z.record(z.string(), z.unknown());
const Terms = z.object({}).catchall(z.unknown());

export const CreateTransactionSchema = z.object({
  buyerUserId: z.uuid(),
  categorySlug: z.string().trim().min(1).max(80),
  productName: z.string().trim().min(2).max(160),
  description: z.string().trim().min(1).max(5000),
  priceMinor: z.number().int().positive(),
  currency: z.literal('GHS').default('GHS'),
  quantity: z.number().int().positive().max(100000),
  condition: z.string().trim().min(1).max(2000),
  deliveryTerms: Terms.default({}),
  returnTerms: Terms.default({}),
  specificationItems: z.array(z.object({
    fieldKey: z.string().trim().min(1).max(120),
    label: z.string().trim().min(1).max(200),
    value: z.unknown()
  })).default([])
});
export type CreateTransaction = z.infer<typeof CreateTransactionSchema>;

export const ConfirmSpecificationSchema = z.object({
  confirmationHash: z.string().regex(/^[a-fA-F0-9]{64}$/).optional()
});

export const AmendSpecificationSchema = CreateTransactionSchema.omit({ buyerUserId: true }).extend({
  reason: z.string().trim().min(1).max(1000)
});

export type ConfirmSpecification = z.infer<typeof ConfirmSpecificationSchema>;
export type AmendSpecification = z.infer<typeof AmendSpecificationSchema>;
