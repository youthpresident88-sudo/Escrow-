# Operations Platform

## Roles
- `super_admin`: full operational control and role administration.
- `operations`: transaction/dispute/support operational workflows.
- `dispute_reviewer`: dispute review and decisions permitted by the dispute engine.
- `support`: support cases and customer assistance.
- `risk_analyst`: KYC manual review and risk cases.
- `finance`: reconciliation and financial operations.
- `compliance`: KYC/compliance oversight.

All administrative endpoints require an authenticated user with the relevant role. High-impact domain workflows remain enforced by their domain services; the operations console does not bypass transaction state machines.

## Evidence integrity
Administrative users can inspect evidence but do not receive a generic evidence mutation API. A database trigger rejects staff UPDATE/DELETE operations on historical evidence. Corrections must create a new evidence version through the Evidence Vault workflow.

## Audit
Administrative actions are written to both the existing `audit_log` and the append-oriented `operations_action_log`. Finance reconciliation, support actions and administrative inspection routes are therefore traceable.

## Runtime setup
Run migration `0012_operations_platform.sql` after the existing migrations. Grant operational roles only to named staff accounts using the existing role-administration process; `super_admin` is required to grant privileged administrative roles.
