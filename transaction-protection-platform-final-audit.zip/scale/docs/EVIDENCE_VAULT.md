# Evidence Vault

The Evidence Vault is an evidence timeline, not a generic file store.

## Integrity model

1. The API authorizes the uploader against the transaction and evidence type.
2. The API creates a one-time Supabase Storage signed upload URL for a private bucket.
3. The browser uploads the original object directly to private object storage and reports progress.
4. The completion endpoint downloads the stored object through a short-lived signed URL and independently calculates SHA-256 over the stored bytes.
5. The object is marked verified only when stored byte size and any supplied client hash match server verification.
6. The original object is never replaced by a correction. Corrections create a new evidence version and mark the prior version non-current.
7. Evidence events record upload creation, completion, hashing, verification, access and version changes.

A SHA-256 hash verifies byte integrity; it does not by itself prove when the recording was originally created.

## Access

The API only issues signed read URLs after transaction authorization. Buyer/seller access is transaction-scoped. Staff roles can access evidence needed for support/risk/admin operations. Direct bucket access is private.

## Large files

Uploads are direct-to-storage rather than buffered through PostgreSQL. The browser reports upload progress. The server verifies the completed stored object. Client-side SHA-256 is optional for large files to avoid loading a very large object into browser memory; server-side hashing remains mandatory.

## Recovery

A failed transfer can be retried while its signed upload URL remains valid. A failed verification is recorded as a failed upload; the original stored object is not silently substituted. Production clients should retain the upload descriptor until completion and request a new descriptor when the URL expires.

## Privacy

Only metadata needed for evidence integrity and workflow should be collected. Device and capture metadata are stored as structured JSON and should be minimized according to the platform's Ghana data-protection/privacy policy and any other applicable law.

## Scale upload policy
For files above the small-upload threshold, clients should use the returned TUS resumable-upload configuration. Supabase recommends TUS for large or unreliable uploads and provides CDN-backed Storage delivery. Never overwrite an existing evidence object; create a new version/path instead.
