# Scale Architecture Decision Record

The platform remains a modular monolith at the API boundary, but is horizontally scalable because API instances are stateless and durable state is externalized to PostgreSQL and object storage. Background work is separated into workers.

The first scaling boundary is:

`Load balancer/WAF -> API replicas -> PostgreSQL primary/read replica + object storage`

and

`Database outbox/jobs -> horizontally scaled workers -> providers`

Do not split into dozens of microservices before measured bottlenecks justify it. The transaction/evidence invariants should remain in one transactional boundary until throughput, team ownership or fault isolation requires a service split.
