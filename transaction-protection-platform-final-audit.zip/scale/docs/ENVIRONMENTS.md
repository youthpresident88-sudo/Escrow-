# Environments
Local, test, staging and production use separate databases, storage and secrets. Production credentials are never committed or reused locally. See `.env.example` for the required configuration surface.

## Authentication / identity

Required for production authentication:

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY` (server only)
- `RESEND_API_KEY`
- `EMAIL_FROM`
- `TWILIO_ACCOUNT_SID`
- `TWILIO_AUTH_TOKEN`
- `TWILIO_FROM_NUMBER`

Supabase Auth SMS must be configured with a real SMS provider (Twilio) for `/v1/auth/phone/otp` and `/v1/auth/phone/verify`. The application never stores or generates the OTP itself; Supabase Auth and the configured provider do.
