# Production Security Review

## Authentication / authorization

- Supabase JWT validation is server-side.
- Staff access is role-gated.
- Financial, dispute, KYC, risk and operations actions are audited.
- PostgreSQL RLS is enabled for user-facing sensitive tables.
- Historical evidence is immutable; corrections create versions.
- Privileged role assignment is restricted to super-admin authorization.

## OWASP-oriented controls

- Injection: parameterized PostgreSQL queries; validate request bodies with Zod where contracts exist.
- XSS: React escaping; do not render untrusted HTML. Email templates must HTML-escape dynamic content before production hardening.
- CSRF: bearer-token API model; if cookie authentication is added, require SameSite/CSRF protection.
- SSRF: external-provider URLs must be allowlisted/configured; never fetch arbitrary user-supplied URLs from server workers.
- File access: private bucket, application authorization, short-lived signed URLs, immutable paths.
- Secrets: provider secrets are environment/server-side only.
- Webhooks: verify provider signatures before processing; store provider event IDs with unique constraints.
- Payment manipulation: frontend cannot mark a payment successful; only verified provider events/reconciliation can move financial state.
- Privilege escalation: role changes require super-admin authorization and all admin actions are audited.
- Rate abuse: API rate limiting plus provider/edge limits; add account/device/IP-specific controls for authentication and financial endpoints.
- Account takeover: session tracking, security events, OTP verification and risk signals are available; high-impact restrictions require human review.

## Evidence privacy

Capture only metadata necessary for the evidence purpose. Recording timestamps are not treated as cryptographic proof of original capture time. Avoid exposing unrelated personal data in IMEI/serial, packaging and delivery recordings.

## High-impact decisions

Risk scoring is advisory. Serious fraud, account restriction, dispute financial decisions and KYC rejection require the defined human/regulated-provider workflow; weak signals must not be treated as proof of fraud.

## Operational security requirements before launch

- WAF/edge rate limits enabled.
- TLS-only production endpoints.
- Secrets stored in managed secret storage.
- MFA enforced for staff roles.
- Database least-privilege service accounts where supported.
- Production logging excludes tokens, OTPs, payment secrets and raw identity documents.
- Dependency and container scanning in CI.
- Quarterly access review.
