# Production Scale & Reliability

## Target architecture

- Stateless API replicas behind a load balancer.
- PostgreSQL primary for writes plus `DATABASE_READ_URL` for read replicas.
- PgBouncer or managed connection pooling in front of PostgreSQL; API pools remain bounded.
- Durable PostgreSQL job queues using `FOR UPDATE SKIP LOCKED`; horizontally scalable workers.
- Supabase Storage private bucket for evidence, CDN-backed delivery, signed URLs and TUS resumable uploads.
- Background processing for evidence hashing, notifications, reconciliation and risk work.
- Cursor pagination for high-volume operational lists.
- Immutable event/audit records; cold records are archived out of hot paths.

## Database

Hot indexes were added for transaction events, evidence events/uploads, payment reconciliation, webhooks, audit logs and notifications.

For very large deployments:

1. Put PgBouncer/managed pooling between services and Postgres.
2. Keep OLTP writes on the primary.
3. Route safe read-only queries to `DATABASE_READ_URL`.
4. Partition high-growth append-only tables by time when they reach operational thresholds (for example transaction events, audit logs and evidence events). Partitioning should be introduced with a controlled migration/dual-write or archive plan rather than an in-place destructive rewrite.
5. Archive old audit/transaction-event rows to the append-only archive tables using scheduled jobs and retain according to legal/regulatory policy.
6. Use managed PITR backups plus periodic restore drills. Backups are not considered verified until a restore succeeds.

## Object storage

Evidence remains outside PostgreSQL. Supabase Storage provides private buckets, signed URLs, CDN delivery and TUS resumable uploads. Large files should use resumable uploads; standard uploads are appropriate only for small files.

Use unique immutable object paths. Never overwrite an evidence object. Apply lifecycle policies to abandoned upload objects and temporary processing artifacts, but never delete evidence required by an active legal/dispute retention policy.

## Queues

`public.jobs` is the durable control queue. Workers claim jobs using `SKIP LOCKED`, increment attempts, retry with exponential backoff, and move permanently failing jobs to `dead_letter`.

Notification delivery already uses a durable outbox. Evidence hashing is now worker-backed so large recordings do not occupy API request workers while the server computes SHA-256.

A managed Redis/Kafka/SQS-style queue may be introduced later for extremely high throughput, but it must remain an acceleration layer—not the only durable record for financial/evidence events.

## API scalability

- bounded DB pools
- statement and connection timeouts
- request timeouts
- idempotency on financial/state-changing operations
- provider webhook deduplication
- cursor pagination
- structured request IDs
- health/readiness endpoints
- graceful shutdown
- rate limiting at API edge/load-balancer and application layers

For multi-region or multi-instance rate limiting, use a shared provider/Redis-backed limiter at the edge; do not depend on a single process's memory.

## Caching

Cache only non-sensitive, low-volatility data such as category definitions. Do not cache authenticated transaction/payment/evidence responses at a shared CDN. Private evidence uses signed URLs.

## Backup / DR

### RPO/RTO targets to configure with the managed database provider

- Financial/evidence metadata RPO: <= 5 minutes.
- Core API RTO: <= 60 minutes.
- Evidence object RPO: provider durability target plus independent backup/replication policy.

### Disaster procedure

1. Freeze high-risk financial operations if integrity is uncertain.
2. Verify provider/database incident scope.
3. Promote the approved database replica or restore to a known-good PITR point.
4. Repoint API/worker secrets/configuration.
5. Replay unprocessed webhook events and durable jobs idempotently.
6. Verify transaction/payment/evidence invariants.
7. Resume payouts only after finance reconciliation.
8. Record the incident and recovery evidence.

Perform quarterly restore drills and record measured RPO/RTO.

## Failure handling

- Payment provider outage: initialization fails explicitly; already-authorized transactions remain governed by persisted provider events and reconciliation.
- Database outage: readiness fails; stateless API instances stop accepting work that requires DB access.
- Queue outage: events remain in the database outbox/job table and are retried after workers recover.
- Duplicate webhooks: provider/event unique constraints make processing idempotent.
- Interrupted upload: TUS resumes from the last confirmed offset.
- Partial failure: each external side effect has a durable operation/event record and reconciliation path.
- Deployment failure: use immutable builds, health-gated rollout, and rollback to the last known-good version.
