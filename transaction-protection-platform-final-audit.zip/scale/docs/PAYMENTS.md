# Production Payment Infrastructure

## Regulatory/provider model

For Ghana, the platform uses a provider adapter rather than integrating directly with mobile-money wallets. The initial production adapter is **Paystack Ghana**, which is listed by the Bank of Ghana as a PSP Enhanced. The Bank of Ghana's current licensed-PSP register must be checked before enabling a provider in any operating country.

The application does not hold or process MoMo PINs, card CVVs, card PINs or OTPs. Those are handled by the payment provider/network's secure authorization flow.

Paystack supports Ghana card, bank and mobile-money channels. For Ghana mobile money, supported provider codes include `mtn`, `vod` (Telecel) and `atl` (AT/Airtel Money). Mobile-money completion is asynchronous and the server relies on verified provider webhooks and reconciliation rather than a browser success callback.

## Environment

Required for real payment operation:

```env
PAYSTACK_SECRET_KEY=sk_live_...
PAYSTACK_WEBHOOK_SECRET=...
PAYSTACK_BASE_URL=https://api.paystack.co
APP_BASE_URL=https://your-web-domain.example
API_BASE_URL=https://your-api-domain.example
```

`PAYSTACK_WEBHOOK_SECRET` should normally be the secret used by the provider for webhook signature validation. If it is omitted, the adapter falls back to the Paystack secret key; explicitly setting it is preferred.

Never commit these values. Use the production secret manager/environment settings.

## Payment flow

1. Transaction reaches `awaiting_payment` only after the specification is locked.
2. Buyer calls `POST /v1/transactions/:id/payment` with an `Idempotency-Key`.
3. The API initializes a real Paystack transaction.
4. The API records the payment as `pending` and records an immutable payment event.
5. The buyer completes card, bank or mobile-money authorization at the provider.
6. The provider calls `POST /v1/webhooks/paystack`.
7. The server verifies the raw-body HMAC signature before parsing/trusting the event.
8. Provider event IDs are deduplicated.
9. A verified `charge.success` event is the only normal webhook path that moves the transaction to `payment_secured`.
10. Failed/cancelled/expired states remain non-funded and can be retried.
11. Reconciliation periodically verifies unresolved provider transactions and records reconciliation events.

The frontend can never mark a payment successful.

## API

- `POST /v1/transactions/:id/payment`
- `GET /v1/transactions/:id/payment-status`
- `POST /v1/webhooks/paystack`
- `POST /v1/disputes/:id/refund`
- `POST /v1/transactions/:id/payout`
- `POST /v1/admin/payments/reconcile`

## Channels

### Card

Use `channel: "card"`. The provider-hosted authorization flow handles card authentication.

### Mobile money

Use:

```json
{
  "channel": "mobile_money",
  "phone": "0551234567",
  "provider": "mtn"
}
```

Provider values are `mtn`, `vod`, and `atl` for Ghana.

### Bank

Use `channel: "bank_transfer"`. The provider response is stored so the UI can show the actual authorization/instruction returned by the provider.

## Refunds

Refunds use the real provider refund API. Partial refunds are passed as an amount when supported. Provider refund webhooks are recorded and reconcile the internal refund workflow.

Never mark an internal refund as completed merely because a refund request was accepted. Completion requires the provider's final refund event/status.

## Payouts

Seller payouts are provider transfers and must only be initiated after the transaction reaches an eligible resolved state. A payout requires a provider recipient reference created through the provider's official recipient mechanism. Provider transfer events reconcile the payout state.

The platform must maintain sufficient balance/funding and comply with applicable Ghana regulatory, AML/CFT, consumer-protection and safeguarding requirements before live payouts are enabled.

## Reconciliation

Run the reconciliation endpoint from a protected scheduler/worker. It checks unresolved payments against the provider and records the result. A production deployment should run this frequently enough to catch delayed webhooks and provider/network failures.

Recommended operational schedule: every 2–5 minutes for pending payments, plus a daily full reconciliation report.

## Security rules

- Never trust frontend payment status.
- Never accept provider event data without signature verification.
- Store every provider event.
- Deduplicate by provider + provider event ID.
- Use idempotency keys for payment initialization, refunds and payouts.
- Never store MoMo PIN, card CVV, card PIN or provider OTP.
- Keep provider secrets server-side only.
- Never put provider secret keys in browser bundles.
- Do not delete payment events; append corrections/reconciliation events.
- Treat provider and internal ledgers as reconcilable records, not as UI state.
