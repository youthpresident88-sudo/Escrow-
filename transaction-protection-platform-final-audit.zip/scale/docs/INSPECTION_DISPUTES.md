# Buyer Inspection & Dispute Resolution

The inspection system is a structured evidence workflow, not a generic form and not an AI decision engine.

## Inspection lifecycle

`delivered -> inspection -> accepted | disputed`

A buyer starts inspection only after the transaction reaches `delivered`. The category-specific checklist is loaded from the database. Each required item must receive a result. Inspection evidence must be verified Evidence Vault objects when evidence IDs are supplied.

## Dispute levels

- **Level 1 — objective mismatch:** compare the locked specification, delivery evidence, seller evidence, buyer evidence and inspection result.
- **Level 2 — human review:** an authorized support/risk/admin reviewer is assigned and records the evidence considered, decision and reason.
- **Level 3 — expert/manual review:** used where technical inspection, authenticity or other specialist judgment is required.

AI is not used as the sole decision-maker for fraud, authenticity, refunds or other serious financial outcomes.

## Required dispute references

A dispute stores the locked specification ID and snapshots the verified seller, buyer and delivery evidence IDs available at creation. It also references the inspection. Additional evidence is stored through `dispute_evidence`.

## Returns

Return states are recorded independently:
`requested -> approved -> in_transit -> received -> inspected -> completed`.
Every status change creates a return event.

## Refunds

A dispute decision authorizes a refund; it does **not** falsely mark money as refunded. The platform creates a `refund_request`, transitions the transaction to `refund_pending`, calls the configured Paystack refund API, and waits for Paystack refund webhooks. Only `refund.processed` moves the transaction to `refunded`; `refund.failed` moves it back to `disputed`.

Paystack documents `refund.pending`, `refund.processing`, `refund.needs-attention`, `refund.failed`, and `refund.processed` webhook states. A processed refund can still take time to reach the customer. See the official Paystack refund documentation.
