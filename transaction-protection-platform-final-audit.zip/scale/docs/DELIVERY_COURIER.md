# Delivery & Courier Infrastructure

## Principle
Delivery is part of the protected transaction's evidence and financial chain. A payment is not released merely because a courier says an item was delivered. Delivery state is recorded with immutable event history and linked evidence; the transaction engine remains the financial authority.

## Lifecycle
`payment_secured -> delivery ready -> dispatched -> picked_up -> in_transit -> delivery_attempted* -> delivered -> inspection`

`delivery_attempted` does not release funds and can return to in-transit. Only verified delivery confirmation moves the protected transaction from `dispatched` to `delivered`.

## Delivery record
Each transaction can have one delivery record containing:
- tracking reference
- provider/internal route
- pickup and destination data
- package count/weight/dimensions
- assigned courier
- dispatch/pickup/delivery timestamps
- delivery confirmation PIN hash and expiry
- exception/failure metadata

## Evidence chain
- Seller: `dispatch` / `packaging`
- Courier: `pickup`
- Courier/recipient: `delivery` / `delivery_confirmation`
- All evidence remains in the existing private Evidence Vault.
- Evidence is SHA-256 verified by the existing asynchronous evidence worker.
- Delivery events store the evidence IDs used for each milestone.
- Historical evidence is immutable; corrections use evidence versioning.

## Confirmation
A buyer can confirm delivery while authenticated. A courier must provide the short-lived delivery PIN supplied to the recipient plus delivery evidence. Operations can perform an audited override when operational policy permits it. The plaintext PIN is never stored.

## Tracking
Courier tracking points are stored separately from the financial event ledger. They are operational telemetry, not proof of delivery by themselves. Access is restricted to the transaction parties, assigned courier and authorized staff.

## Courier authorization
A user must have the `courier` role before assignment. Operations staff assign/release couriers. Courier actions are limited to deliveries assigned to that courier.

## Provider architecture
`provider='internal'` is the first real execution path. External courier integrations should implement a provider adapter for:
- create shipment
- cancel shipment
- assign/accept
- dispatch/pickup
- tracking webhook
- delivery confirmation
- delivery exception

External provider webhooks must be signature-verified, idempotent and mapped into `delivery_events`. They must never directly release funds.

## Failure handling
- duplicate courier events: idempotency keys/event uniqueness
- interrupted evidence upload: existing TUS resumable upload
- provider outage: delivery remains in its last verified state; no financial transition is inferred
- courier failure: record a delivery attempt/exception with evidence
- database outage: API rejects state-changing requests rather than inventing success
- notification outage: delivery state remains authoritative; notification retries independently

## Operational metrics
Track:
- dispatch-to-pickup duration
- pickup-to-delivery duration
- delivery attempt rate
- failed delivery rate
- evidence verification latency
- courier acceptance latency
- provider webhook failures
- deliveries stuck in each state
- confirmation method distribution
