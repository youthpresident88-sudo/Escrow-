# Implementation plan
1. Foundation: repository, schema, auth, transaction commands, audit, payment webhook boundary. **Started.**
2. Evidence vault: private/resumable storage, server validation, SHA-256, signed access.
3. State machine: seller preparation, dispatch, delivery, inspection, acceptance and payout eligibility.
4. Disputes: structured cases, evidence bundles, assignments, SLA timers, decisions and reason codes.
5. Risk/trust: velocity rules, anomaly signals, seller trust profiles and manual review.
6. Notifications: real email/SMS/push adapters, retry/backoff/dead-letter handling.
7. Production operations: tracing, metrics, alerts, reconciliation, backups, restore drills and load testing.
8. Mobile: camera-first evidence capture and Android/iOS release clients.

## Completed: Buyer Inspection + Dispute Resolution

- Category-specific inspection templates and checklist items
- Delivery-gated buyer inspection lifecycle
- Inspection result persistence and transaction-state transitions
- Structured dispute reasons and evidence references
- Level 1 objective mismatch, Level 2 human review, Level 3 expert/manual review
- Reviewer assignment and reviewer decision records
- Appeal workflow
- Return lifecycle and return event audit trail
- Real Paystack refund initiation and refund webhook reconciliation
- Refund is never marked successful merely because a decision was recorded
- In-app notification outbox events for inspection/dispute/refund milestones
- No autonomous AI financial/fraud decision path
