# Production architecture

**Shape:** modular monolith first; separate deployables for web, API and workers. This avoids premature microservice complexity while keeping explicit module boundaries.

**System of record:** PostgreSQL/Supabase Postgres. **Auth:** Supabase Auth/JWT. **Evidence:** private object storage with database metadata and SHA-256 fingerprints. **Async:** notification/event outbox + worker, with Redis/queue infrastructure planned for high volume. **Payments:** provider adapter with Paystack as the first Ghana integration; provider-signed webhooks are authoritative. **Observability:** structured logs first, then OpenTelemetry/Sentry/metrics in staging/production.

## Dependency map
Web → Supabase Auth → API → PostgreSQL
API → object storage
API → payment provider
API → outbox → workers → email/SMS/push providers
Payment provider → signed webhook → API → PostgreSQL → worker

## Core modules
Identity/access; transactions/state machine; evidence/integrity; payments/reconciliation; notifications; disputes/resolution; risk/fraud; admin/operations; audit/observability.

## Transaction lifecycle
`draft → awaiting_payment → payment_pending → funded → seller_preparing → dispatched → delivered → inspection_pending → accepted → paid_out`.

Exceptional states include cancellation/expiry/payment failure, dispute, return and refund. State changes are server-side only and create immutable transaction events.

## Scale path
Keep Postgres authoritative. Add connection pooling, indexes, read replicas/caching, queue workers, object-storage CDN, partitioning of very large append-only event/audit tables, and service extraction only when measurements/team boundaries justify it. Do not claim a million-user capacity without load testing.
