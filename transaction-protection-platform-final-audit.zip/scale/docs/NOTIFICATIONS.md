# Production Communications

The platform uses a durable PostgreSQL notification outbox as the queue. API requests enqueue notification intent; the background worker performs provider delivery and records acceptance/failure. External provider calls are never made from the user-facing request path.

## Providers

- Email: Resend transactional email API.
- SMS: Twilio Programmable Messaging with status callbacks.
- Push: standards-based Web Push using VAPID subscriptions. Browser push is provider-independent and does not require storing provider credentials in the client.
- In-app: PostgreSQL notification center.

Providers are adapters at the worker boundary. Notification templates are keyed by event and can be localized later without changing event producers.

## Status semantics

`queued` → `processing` → `accepted` → `delivered` where the provider supplies delivery confirmation. `failed` retries with exponential backoff. After 8 failed attempts the notification becomes `dead_letter` and requires operational review.

An SMS/email is never reported as sent merely because an API request was attempted. The worker records provider acceptance only after the provider returns a provider message ID. Delivery callbacks update final delivery status where available.

## Required environment

`RESEND_API_KEY`, `EMAIL_FROM`, `RESEND_WEBHOOK_SECRET`, `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM_NUMBER`, `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `VAPID_SUBJECT`.

If a channel provider is not configured, that channel fails explicitly and enters the retry/dead-letter path. There is no fake provider.

## Webhooks

- Resend: `POST /v1/webhooks/resend` with Svix signature verification.
- Twilio: `POST /v1/webhooks/twilio/status` with `X-Twilio-Signature` verification.

Configure provider callbacks to the production API URL and use HTTPS.

## Security

No card CVV/PIN, MoMo PIN, SMS OTP, provider API keys, or VAPID private key is exposed to clients. Push subscriptions contain only the browser subscription endpoint and public-key material required by Web Push.

Notification preferences are user-scoped. Security notifications have independent preference flags so critical account alerts can remain enabled even when ordinary channels are disabled.

## Operations

Monitor `notifications` and `notification_outbox` for `failed` and `dead_letter` records. The durable queue survives worker restarts. Idempotency keys prevent duplicate logical notifications; provider message IDs and provider event IDs prevent duplicate callback processing.
