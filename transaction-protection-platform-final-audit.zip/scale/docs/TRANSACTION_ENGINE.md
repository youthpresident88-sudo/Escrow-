# Transaction Engine

The transaction engine is agreement-first. A seller creates the transaction and its versioned specification; the seller confirms; the buyer confirms; PostgreSQL locks the specification and only then makes protected payment available.

## Lifecycle

`created -> specification_pending -> specification_locked -> awaiting_payment -> payment_pending -> payment_secured -> awaiting_dispatch -> dispatched -> delivered -> inspection -> accepted`

Dispute/resolution branches are controlled by the database transition function.

## Invariants

- Frontends never write `transactions.status` directly.
- Every state transition is an append-only `transaction_events` record.
- `transition_transaction()` locks the transaction row with `FOR UPDATE`.
- Idempotency keys are stored with the transition event.
- Specification versions are immutable after lock.
- Amendments create a new version and supersede the previous locked version without modifying its content.
- Payment cannot be initialized until the specification reaches `awaiting_payment`.
- Provider payment confirmation moves the transaction to `payment_secured` through the same state machine.
- Product categories are data-driven and category fields live outside the core transaction schema.
