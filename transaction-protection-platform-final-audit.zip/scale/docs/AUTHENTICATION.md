# Production Authentication and Identity

## Provider model

- Supabase Auth is the identity/session authority.
- Resend is the transactional email provider.
- Supabase Auth SMS is configured with a real SMS provider (Twilio) for phone OTP.
- PostgreSQL stores application session metadata and revocation state.
- Access tokens are verified by Supabase Auth before protected API access.
- Application session IDs are checked against `auth_sessions`, allowing server-side revocation before JWT expiry.

## Flows

### Registration
1. Server validates email, password, name and optional E.164 phone.
2. Supabase Auth creates the user with email unconfirmed.
3. Application assigns the default buyer role; seller registration also creates a seller profile and seller role.
4. Supabase generates a signed verification link.
5. Resend accepts the verification email.

### Email verification
`POST /v1/auth/email/verify` accepts the single-use Supabase token hash and confirms the account.

### Email/password login
Supabase validates the password. The API rejects unverified email accounts, records the authenticated provider session ID, and creates application session metadata.

### Phone OTP
`POST /v1/auth/phone/otp` calls Supabase Auth's real SMS OTP flow. Supabase must be configured with Twilio (or another supported production SMS provider). OTP values never enter application storage.

### Password recovery
The server generates a signed Supabase recovery link and sends it through Resend. The link token is exchanged at `/v1/auth/password-reset/exchange`, then the authenticated recovery session can change the password.

### Session revocation
A user can list and revoke their application sessions. Every protected request checks the provider JWT and then checks the corresponding application session record. Global logout also asks Supabase to revoke the provider sessions.

### Roles
Public registration can create only `buyer` or `seller`. Support, risk analyst, admin and super-admin roles are assigned by protected administrative operations. PostgreSQL also blocks non-privileged role self-granting.

## Production requirements

Configure the following secrets in the server environment only:

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `RESEND_API_KEY`
- `EMAIL_FROM`
- `TWILIO_ACCOUNT_SID`
- `TWILIO_AUTH_TOKEN`
- `TWILIO_FROM_NUMBER`

Never expose `SUPABASE_SERVICE_ROLE_KEY`, Resend keys or Twilio credentials to browser/mobile code.
