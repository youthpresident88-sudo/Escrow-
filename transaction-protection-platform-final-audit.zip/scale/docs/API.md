# API v1
GET /health — liveness
GET /ready — database readiness
POST /v1/transactions — authenticated transaction creation; requires Idempotency-Key
GET /v1/transactions/:id — authenticated participant/staff read
POST /v1/transactions/:id/payment — real Paystack initialization; requires Idempotency-Key and PAYSTACK_SECRET_KEY
POST /v1/webhooks/paystack — signed provider webhook

## Delivery & Courier API

- `POST /v1/admin/couriers` — create/update a courier operational profile; operations role required.
- `POST /v1/transactions/:id/delivery` — create a protected delivery record after payment is secured.
- `GET /v1/transactions/:id/delivery` — retrieve delivery, assignments, events and tracking for an authorized participant/courier/staff member.
- `POST /v1/deliveries/:id/assign` — operations assigns a courier.
- `POST /v1/deliveries/:id/accept` — assigned courier accepts.
- `POST /v1/deliveries/:id/dispatch` — seller/operations records dispatch with linked evidence.
- `POST /v1/deliveries/:id/pickup` — assigned courier records pickup with linked evidence and optional location.
- `POST /v1/deliveries/:id/in-transit` — courier records in-transit state.
- `POST /v1/deliveries/:id/tracking` — courier submits a tracking point.
- `POST /v1/deliveries/:id/attempt` — courier records a failed delivery attempt with evidence.
- `POST /v1/deliveries/:id/confirm` — buyer confirms delivery or courier confirms with the recipient PIN and delivery evidence. This is the only delivery operation that advances the transaction to `delivered`.
- `GET /v1/courier/deliveries` — cursor-paginated courier workload.

All state-changing delivery endpoints must use authentication and idempotency where specified. Delivery events are immutable operational records and evidence IDs link each milestone to the Evidence Vault.
