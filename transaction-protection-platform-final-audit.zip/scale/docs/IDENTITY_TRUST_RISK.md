# Identity, Trust & Risk

## Identity provider
The application uses a provider abstraction. The configured production adapter is Smile Identity. It is not a local/fake verifier: requests are sent to the provider and only provider responses/webhooks update verification state.

Required server secrets:
- `SMILE_IDENTITY_BASE_URL`
- `SMILE_IDENTITY_API_KEY`
- `SMILE_IDENTITY_PARTNER_ID`
- `SMILE_IDENTITY_WEBHOOK_SECRET`

If these are absent, identity verification endpoints return `503` and never return a fabricated verification result.

Before production launch, confirm the exact Smile Identity API product/version, enabled countries/document types, webhook signing configuration, data-processing terms, retention rules and callback URL with Smile Identity. The adapter isolates those provider-specific details from the transaction engine.

## Verification lifecycle
`pending -> verified | rejected`; rejected cases may be retried up to three times and can enter manual review. Provider metadata is retained for audit, while sensitive raw identity documents should remain with the regulated verification provider unless the platform has a documented lawful basis, retention schedule and secure storage design.

Ghana's Data Protection Act regulates personal-data processing, and biometric data requires particular care. The platform therefore stores provider references and verification outcomes rather than copying unnecessary biometric payloads into the core transaction database. citeturn0search24turn0search23

## Trust
Trust metrics are calculated from transaction outcomes. Legitimate returns are tracked separately and are not treated as seller-fault disputes or generic fraud signals.

## Risk
Risk signals are evidence, not accusations. The system records signal type, severity, score contribution, confidence, evidence and source. High-impact actions require a human risk analyst and create an immutable case event trail.

Signals supported by the schema include failed-payment velocity, repeated account/device patterns, transaction velocity, dispute patterns, account-takeover indicators, payment anomalies, evidence anomalies and repeated identity conflicts. Detection producers can write these as `risk_events`.

No automated rule alone labels a person a fraudster. Weak signals can contribute to review but do not directly create an irreversible account penalty.

## Ghana regulatory context
The Bank of Ghana identifies KYC/CDD authentication services among PFTSP activities and publishes licensing requirements for regulated fintech/payment activities. Where the platform itself performs regulated activity rather than using licensed partners, legal/regulatory review is required before launch. citeturn0search2turn0search1
